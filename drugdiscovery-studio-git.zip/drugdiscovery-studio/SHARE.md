# How to Share DrugDiscovery Studio With Others

## Option 1 — Share the live preview link (fastest, minutes)

The app already runs on a public URL in this workspace (the "live preview" tab
in this chat):

```
https://8000-<your-sandbox-id>.e2b.app        (shown in your preview panel)
```

You can copy that URL and send it to colleagues — it works from any browser,
no install needed.

**Limitations:**
- The link lives only while this sandbox session is alive (it sleeps when idle;
  ask me to restart the server and it's back in seconds).
- It's one shared demo server — fine for trying the app, not for private data.

## Option 2 — Send the project (colleagues run it locally, ~10 min setup)

I've prepared `egfr_affinity_share.zip` in the workspace — it contains all code
and docs (not the bulky raw datasets; those re-download automatically).

They just need Python 3.10+:

```bash
unzip egfr_affinity_share.zip && cd egfr_affinity
pip install -r requirements.txt

# open the app (uses the pre-trained EGFR model if artifacts are included,
# or trains on first request):
python app/server.py            # → http://localhost:8000

# to (re)build the EGFR model from scratch (~15 min, downloads public data):
python run_pipeline.py
# train any other protein on demand:
python src/train_target.py --target CHEMBL5145
```

Also fine to push this folder to a **private GitHub repo** and add teammates.

## Option 3 — Deploy it as a permanent public app (recommended for teams)

Free/cheap hosts that run this Flask app as-is (each ~10 min):

1. **Hugging Face Spaces (free, easiest for ML demos)**
   - Create a new Space → SDK: "Docker"
   - Upload this folder (it has a `Dockerfile` ready — uses port 7860 via env `PORT`)
   - It builds and gives you a permanent URL like `https://you-dds.hf.space`
2. **Render / Railway / Fly.io**
   - New Web Service → point at the repo → it auto-detects the `Dockerfile`
3. **Your own server / cloud VM**
   - `docker build -t dds . && docker run -p 8000:8000 dds`

**Deploy notes:**
- The `Dockerfile` bakes in the **EGFR model** so the app works immediately;
  every other protein trains on demand (~4 min each, from inside the app).
- Storage is ephemeral on free tiers — newly trained targets survive a few
  days; retraining is one click.
- For real team use, add a password/API key in front (any host supports this)
  or host it inside your VPN — never put unreleased compound structures on a
  public URL.

## What NOT to share without checking first

- If you scored *proprietary* molecules through this preview, treat the
  results CSVs as confidential — structure = your IP. The demo candidates in
  the repo are all public drugs.
