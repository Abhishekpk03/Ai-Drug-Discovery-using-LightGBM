"""
Bemis–Murcko scaffold split (DeepChem-style greedy assignment).

All compounds sharing a scaffold land in ONE partition, so the test set contains
novel chemotypes unseen during training — the honest generalization test.
"""
import argparse

import numpy as np
import pandas as pd
from rdkit import Chem, RDLogger
from rdkit.Chem.Scaffolds import MurckoScaffold

RDLogger.DisableLog("rdApp.*")


def murcko_scaffold(smiles: str) -> str:
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        return ""
    try:
        scaff = MurckoScaffold.GetScaffoldForMol(mol)
        return Chem.MolToSmiles(scaff, isomericSmiles=False) if scaff is not None else ""
    except Exception:
        return ""


def scaffold_split(df: pd.DataFrame, smiles_col="std_smiles",
                   frac_train=0.8, frac_val=0.1, frac_test=0.1, seed: int = 0):
    assert abs(frac_train + frac_val + frac_test - 1.0) < 1e-6
    rng = np.random.default_rng(seed)
    scaffolds = {}
    for idx, smi in zip(df.index, df[smiles_col]):
        scaffolds.setdefault(murcko_scaffold(smi), []).append(idx)

    # shuffled tie-breaking, then largest scaffold groups first
    groups = list(scaffolds.values())
    rng.shuffle(groups)
    groups.sort(key=len, reverse=True)

    n = len(df)
    splits = {"train": [], "val": [], "test": []}
    cut_train, cut_val = frac_train * n, frac_val * n
    for g in groups:
        if len(splits["train"]) < cut_train:
            splits["train"].extend(g)
        elif len(splits["val"]) < cut_val:
            splits["val"].extend(g)
        else:
            splits["test"].extend(g)

    df = df.copy()
    df["scaffold"] = df[smiles_col].map(murcko_scaffold)
    df["split"] = "train"
    df.loc[splits["val"], "split"] = "val"
    df.loc[splits["test"], "split"] = "test"
    return df


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--in", dest="inp", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--seed", type=int, default=0)
    args = ap.parse_args()
    df = pd.read_csv(args.inp)
    df = scaffold_split(df, seed=args.seed)
    df.to_csv(args.out, index=False)
    s = df["split"].value_counts()
    print(f"train={s.get('train',0)}  val={s.get('val',0)}  test={s.get('test',0)}")
    print(f"unique scaffolds: {df['scaffold'].nunique()} "
          f"(train={df[df.split=='train']['scaffold'].nunique()}, "
          f"test={df[df.split=='test']['scaffold'].nunique()})")


if __name__ == "__main__":
    main()
