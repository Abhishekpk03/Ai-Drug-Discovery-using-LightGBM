"""
Molecular graph featurization (atoms=nodes, bonds=edges) + caching for Tier B.

Atom features (30):
  atomic-number one-hot(12) | degree one-hot(6) | formal charge one-hot(5)
  | hybridization one-hot(6) | aromatic(1)   -> 30

Bond features (12):
  bond-type one-hot(4) | conjugated(1) | in-ring(1) | stereo one-hot(6) -> 12
"""
import os
import pickle

import numpy as np
from rdkit import Chem, RDLogger

RDLogger.DisableLog("rdApp.*")

ATOM_LIST = ["C", "N", "O", "S", "F", "Cl", "Br", "I", "P", "B", "Si", "OTHER"]
HYB_LIST = [Chem.HybridizationType.SP, Chem.HybridizationType.SP2,
            Chem.HybridizationType.SP3, Chem.HybridizationType.SP3D,
            Chem.HybridizationType.SP3D2, Chem.HybridizationType.UNSPECIFIED]
BOND_LIST = [Chem.BondType.SINGLE, Chem.BondType.DOUBLE, Chem.BondType.TRIPLE,
             Chem.BondType.AROMATIC]
STEREO_LIST = [Chem.BondStereo.STEREONONE, Chem.BondStereo.STEREOANY,
               Chem.BondStereo.STEREOZ, Chem.BondStereo.STEREOE,
               Chem.BondStereo.STEREOCIS, Chem.BondStereo.STEREOTRANS]

ATOM_DIM = 12 + 6 + 5 + 6 + 1          # 30
BOND_DIM = 4 + 1 + 1 + 6               # 12


def _onehot(x, lst):
    v = [0] * len(lst)
    try:
        v[lst.index(x)] = 1
    except ValueError:
        v[-1] = 1
    return v


def atom_features(a):
    sym = a.GetSymbol() if a.GetSymbol() in ATOM_LIST else "OTHER"
    return (
        _onehot(sym, ATOM_LIST)
        + _onehot(min(a.GetTotalDegree(), 5), list(range(6)))
        + _onehot(np.clip(a.GetFormalCharge(), -2, 2), [-2, -1, 0, 1, 2])
        + _onehot(a.GetHybridization(), HYB_LIST)
        + [int(a.GetIsAromatic())]
    )


def bond_features(b):
    return (
        _onehot(b.GetBondType(), BOND_LIST)
        + [int(b.GetIsConjugated()), int(b.IsInRing())]
        + _onehot(b.GetStereo(), STEREO_LIST)
    )


def smiles_to_graph(smiles: str):
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        return None
    x = np.array([atom_features(a) for a in mol.GetAtoms()], dtype=np.float32)
    ei, ef = [], []
    for b in mol.GetBonds():
        i, j = b.GetBeginAtomIdx(), b.GetEndAtomIdx()
        f = bond_features(b)
        ei.append([i, j]); ef.append(f)
        ei.append([j, i]); ef.append(f)          # bidirectional
    if ei:
        edge_index = np.array(ei, dtype=np.int64).T   # (2, E)
        edge_feat = np.array(ef, dtype=np.float32)    # (E, BOND_DIM)
    else:  # single atom: self-loop
        edge_index = np.array([[0], [0]], dtype=np.int64)
        edge_feat = np.zeros((1, BOND_DIM), dtype=np.float32)
    return x, edge_index, edge_feat


def featurize_dataframe(df, smiles_col="std_smiles"):
    graphs, keep = [], []
    for i, s in enumerate(df[smiles_col]):
        g = smiles_to_graph(s)
        if g is not None:
            graphs.append(g)
            keep.append(i)
    return graphs, keep


def load_or_build_graphs(df, cache_path, smiles_col="std_smiles"):
    """Cache graphs keyed on DataFrame identity (length + first/last key)."""
    sig = (len(df), str(df.iloc[0]["inchikey14"]), str(df.iloc[-1]["inchikey14"]))
    if os.path.exists(cache_path):
        with open(cache_path, "rb") as f:
            payload = pickle.load(f)
        if payload.get("sig") == sig and payload.get("smiles_col") == smiles_col:
            return payload["graphs"]
    graphs, keep = featurize_dataframe(df, smiles_col)
    assert len(keep) == len(df), f"{len(df) - len(keep)} unparseable SMILES"
    with open(cache_path, "wb") as f:
        pickle.dump({"sig": sig, "smiles_col": smiles_col, "graphs": graphs}, f,
                    protocol=pickle.HIGHEST_PROTOCOL)
    return graphs
