"""
TIER A — baseline: Morgan fingerprints + LightGBM ensemble.

An ensemble of N models (different seeds + bootstrap resampling of training
rows). Prediction = ensemble mean; uncertainty = ensemble std (scaled to the
validation RMSE so 'std' is calibrated in pChEMBL units).

Usage:
    python src/tier_a.py --split data/processed/egfr_split.csv \
        --cache data/processed/fp2048.npz --out artifacts/tier_a --n-members 7
"""
import argparse
import json
import os
import pickle
import time

import lightgbm as lgb
import numpy as np
import pandas as pd

from evaluate import regression_metrics, uncertainty_diagnostics, format_metrics
from features import load_cache

BASE_PARAMS = dict(
    objective="regression",
    n_estimators=4000,
    learning_rate=0.03,
    num_leaves=127,
    min_child_samples=15,
    feature_fraction=0.45,
    bagging_fraction=0.85,
    bagging_freq=1,
    lambda_l2=1.0,
    verbosity=-1,
    n_jobs=min(8, os.cpu_count() or 4),
)


def train_ensemble(Xtr, ytr, Xva, yva, n_members=7, seed0=13, params=None, log_every=0):
    params = dict(BASE_PARAMS, **(params or {}))
    models, rng = [], np.random.default_rng(seed0)
    for k in range(n_members):
        boot = rng.integers(0, len(Xtr), size=len(Xtr))  # bootstrap rows
        m = lgb.LGBMRegressor(seed=seed0 + k, **params)
        m.fit(
            Xtr[boot], ytr[boot],
            eval_set=[(Xva, yva)],
            callbacks=[lgb.early_stopping(200, verbose=False)],
        )
        models.append(m)
        print(f"  member {k+1}/{n_members}: best_iter={m.best_iteration_}, "
              f"val_rmse={m.best_score_['valid_0']['l2']**0.5:.4f}", flush=True)
    return models


def ensemble_predict(models, X):
    preds = np.stack([m.predict(X) for m in models], axis=0)  # (N, n)
    return preds.mean(0), preds.std(0)


def load_split_frames(split_csv, cache):
    df = pd.read_csv(split_csv)
    X = load_cache(df, cache).astype(np.float32)
    y = df["label"].to_numpy(np.float32)
    parts = {s: df["split"].to_numpy() == s for s in ("train", "val", "test")}
    return df, X, y, parts


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--split", required=True)
    ap.add_argument("--cache", required=True)
    ap.add_argument("--out", default="artifacts/tier_a")
    ap.add_argument("--n-members", type=int, default=7)
    args = ap.parse_args()

    os.makedirs(args.out, exist_ok=True)
    df, X, y, parts = load_split_frames(args.split, args.cache)
    Xtr, ytr = X[parts["train"]], y[parts["train"]]
    Xva, yva = X[parts["val"]], y[parts["val"]]
    Xte, yte = X[parts["test"]], y[parts["test"]]
    print(f"train={len(Xtr)}  val={len(Xva)}  test={len(Xte)}")

    t0 = time.time()
    models = train_ensemble(Xtr, ytr, Xva, yva, n_members=args.n_members)
    train_time = time.time() - t0

    # calibrate uncertainty scale on validation residuals
    va_mu, va_sd = ensemble_predict(models, Xva)
    scale = float(np.sqrt(np.mean((va_mu - yva) ** 2)) / max(va_sd.mean(), 1e-6))

    te_mu, te_sd = ensemble_predict(models, Xte)
    te_sd_cal = te_sd * scale
    metrics = regression_metrics(yte, te_mu)
    unc = uncertainty_diagnostics(yte, te_mu, te_sd_cal)
    va_metrics = regression_metrics(yva, va_mu)

    print("\n=== TIER A (LightGBM ensemble x%d) ===" % len(models))
    print("val :", format_metrics(va_metrics))
    print("test:", format_metrics(metrics))
    print("uncertainty:", {k: round(v, 3) for k, v in unc.items()})
    print(f"train_time={train_time:.1f}s")

    with open(os.path.join(args.out, "ensemble.pkl"), "wb") as f:
        pickle.dump({"models": models, "unc_scale": scale}, f)
    res = {"tier": "A", "model": "LightGBM x %d" % len(models),
           "val": va_metrics, "test": metrics, "uncertainty": unc,
           "unc_scale": scale, "train_time_s": train_time}
    with open(os.path.join(args.out, "metrics.json"), "w") as f:
        json.dump(res, f, indent=2)

    pd.DataFrame({
        "inchikey14": df.loc[parts["test"], "inchikey14"],
        "std_smiles": df.loc[parts["test"], "std_smiles"],
        "y_true": yte, "y_pred": te_mu, "uncertainty": te_sd_cal,
    }).to_csv(os.path.join(args.out, "test_predictions.csv"), index=False)


if __name__ == "__main__":
    main()
