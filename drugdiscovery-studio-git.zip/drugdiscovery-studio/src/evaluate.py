"""Shared evaluation metrics."""
import numpy as np
from scipy.stats import spearmanr
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score


def regression_metrics(y_true, y_pred) -> dict:
    y_true, y_pred = np.asarray(y_true, float), np.asarray(y_pred, float)
    return {
        "rmse": float(mean_squared_error(y_true, y_pred) ** 0.5),
        "mae": float(mean_absolute_error(y_true, y_pred)),
        "r2": float(r2_score(y_true, y_pred)),
        "spearman": float(spearmanr(y_true, y_pred).statistic),
        "n": int(len(y_true)),
    }


def uncertainty_diagnostics(y_true, y_pred, y_std) -> dict:
    """Is the uncertainty score useful? Spearman(|error|, u) and error in the
    most/least confident quartiles."""
    y_true, y_pred, y_std = map(lambda a: np.asarray(a, float), (y_true, y_pred, y_std))
    err = np.abs(y_true - y_pred)
    rank_corr = float(spearmanr(err, y_std).statistic)
    hi = y_std >= np.quantile(y_std, 0.75)
    lo = y_std <= np.quantile(y_std, 0.25)
    return {
        "spearman_abs_err_vs_unc": rank_corr,
        "mae_most_confident_quartile": float(err[lo].mean()),
        "mae_least_confident_quartile": float(err[hi].mean()),
    }


def format_metrics(m: dict) -> str:
    return (f"RMSE={m['rmse']:.3f}  MAE={m['mae']:.3f}  R^2={m['r2']:.3f}  "
            f"Spearman={m['spearman']:.3f}  (n={m['n']})")
