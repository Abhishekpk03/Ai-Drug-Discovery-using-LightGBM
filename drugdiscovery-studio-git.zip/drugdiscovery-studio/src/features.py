"""
Molecular featurization + caching.

Morgan/ECFP fingerprints (radius 2, 2048 bits) for Tier A, cached to .npz so
re-training and batched inference never re-run RDKit on known molecules.
"""
import argparse
import os

import numpy as np
import pandas as pd
from rdkit import Chem, RDLogger
from rdkit.Chem import rdFingerprintGenerator

RDLogger.DisableLog("rdApp.*")

_mfpgen = rdFingerprintGenerator.GetMorganGenerator(radius=2, fpSize=2048)


def morgan_fp(smiles: str):
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        return None
    arr = np.zeros((2048,), dtype=np.uint8)
    fp = _mfpgen.GetFingerprintAsNumPy(mol)
    return fp.astype(np.uint8)


def featurize(smiles_list):
    fps, bad = [], []
    for i, s in enumerate(smiles_list):
        f = morgan_fp(s)
        if f is None:
            bad.append(i)
            f = np.zeros((2048,), dtype=np.uint8)
        fps.append(f)
    return np.vstack(fps), bad


def build_cache(df: pd.DataFrame, cache_path: str):
    X, bad = featurize(df["std_smiles"].tolist())
    if bad:
        raise ValueError(f"{len(bad)} unparseable SMILES at rows {bad[:10]}")
    keys = np.array([str(k) for k in df["inchikey14"]], dtype="<U14"); np.savez_compressed(cache_path, X=X, keys=keys)
    return X


def load_cache(df: pd.DataFrame, cache_path: str) -> np.ndarray:
    if os.path.exists(cache_path):
        z = np.load(cache_path, allow_pickle=False)
        keys = np.array([str(k) for k in df["inchikey14"]], dtype="<U14")
        if len(z["keys"]) == len(df) and (z["keys"] == keys).all():
            return z["X"]
    return build_cache(df, cache_path)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--in", dest="inp", required=True)
    ap.add_argument("--cache", required=True)
    args = ap.parse_args()
    df = pd.read_csv(args.inp)
    X = load_cache(df, args.cache)
    print(f"features: {X.shape}, density={X.mean():.4f}")
