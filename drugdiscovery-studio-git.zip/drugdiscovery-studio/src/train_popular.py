"""
Resolve popular drug-target gene names -> ChEMBL ids (via UniProt) and train
Tier A models sequentially in the background. Idempotent: skips already-trained.

    python src/train_popular.py
"""
import os
import subprocess
import sys
import time

import requests

ROOT = os.path.join(os.path.dirname(__file__), "..")
CHEMBL = "https://www.ebi.ac.uk/chembl/api/data"

# (gene symbol, one-line disease relevance)
POPULAR = [
    ("CDK2",    "Cell-cycle kinase — cancer"),
    ("CDK9",    "Transcription kinase — cancer"),
    ("JAK2",    "Cytokine signaling — blood cancers, inflammation"),
    ("ALK",     "Receptor kinase — lung cancer"),
    ("MET",     "Hepatocyte growth factor receptor — cancer"),
    ("PARP1",   "DNA repair enzyme — ovarian/breast cancer"),
    ("HDAC1",   "Epigenetic enzyme — cancer"),
    ("DRD2",    "Dopamine receptor D2 — antipsychotics"),
    ("ADRB2",   "Beta-2 adrenergic receptor — asthma/COPD"),
    ("HTR2A",   "Serotonin receptor 2A — psychiatry"),
    ("HSP90AA1","HSP90 chaperone — cancer"),
    ("PIK3CA",  "PI3K-alpha — breast cancer"),
    ("MTOR",    "Growth checkpoint — cancer, immunosuppression"),
    ("AKT1",    "Survival kinase — cancer"),
    ("ERBB2",   "HER2 — breast cancer"),
    ("ABL1",    "Leukemia kinase (imatinib target)"),
    ("KDR",     "VEGFR2 — angiogenesis, cancer"),
    ("SRC",     "Proto-oncogene kinase — cancer"),
    ("ACE",     "Angiotensin-converting enzyme — hypertension"),
    ("AR",      "Androgen receptor — prostate cancer"),
]


def resolve(gene):
    """Gene symbol -> (chembl_id, uniprot, target_name) or None."""
    try:
        u = requests.get("https://rest.uniprot.org/uniprotkb/search",
                         params={"query": f"gene:{gene} AND organism_id:9606 AND reviewed:true",
                                 "fields": "accession,protein_name", "format": "json", "size": "3"},
                         timeout=30).json()
        for e in u.get("results", []):
            acc = e["primaryAccession"]
            tr = requests.get(f"{CHEMBL}/target.json",
                              params={"target_components__accession": acc, "limit": 8},
                              timeout=30).json()
            best = None
            for t in tr.get("targets", []):
                if t.get("organism") == "Homo sapiens" and t.get("target_type") == "SINGLE PROTEIN":
                    best = t
                    break
            if best:
                return best["target_chembl_id"], acc, best["pref_name"]
    except Exception as ex:
        print(f"  resolve error for {gene}: {ex}", flush=True)
    return None, None, None


def already_trained(tid):
    return os.path.exists(os.path.join(ROOT, "artifacts/targets", tid, "ensemble.pkl")) or tid == "CHEMBL203"


def main():
    for gene, why in POPULAR:
        tid, acc, name = resolve(gene)
        print(f"\n=== {gene} ({why}) -> {tid} / {acc} / {name}", flush=True)
        if not tid:
            print("  SKIP: could not resolve", flush=True)
            continue
        if already_trained(tid):
            print("  SKIP: already trained", flush=True)
            continue
        art = os.path.join(ROOT, "artifacts/targets", tid)
        os.makedirs(art, exist_ok=True)
        import json
        with open(os.path.join(art, "target_info.json"), "w") as f:
            json.dump({"name": name, "organism": "Homo sapiens", "gene": gene, "why": why}, f)
        r = subprocess.run([sys.executable, os.path.join(ROOT, "src/train_target.py"),
                            "--target", tid], cwd=ROOT)
        print(f"  done (rc={r.returncode})", flush=True)
        time.sleep(2)
    print("\nALL DONE", flush=True)


if __name__ == "__main__":
    main()
