"""
Download binding-affinity activity data from the ChEMBL web API
(https://www.ebi.ac.uk/chembl/api/data/) for a given target.

Usage:
    python src/download_chembl.py --target CHEMBL203 --out data/raw/egfr_chembl203.csv
    python src/download_chembl.py --fetch-kinase-family  # transfer-learning pool

Filters applied at query time (more filters later in data_prep.py):
  - standard_type in {Ki, Kd, IC50}
  - pchembl_value present (>= 3, i.e. weaker than 1 mM, keeps everything real)
"""
import argparse
import json
import time

import pandas as pd
import requests

BASE = "https://www.ebi.ac.uk/chembl/api/data"

FIELDS = [
    "activity_id", "molecule_chembl_id", "canonical_smiles",
    "standard_type", "standard_relation", "standard_value", "standard_units",
    "pchembl_value", "assay_type", "assay_chembl_id", "assay_description",
    "target_organism", "document_chembl_id", "bao_label",
    "assay_variant_mutation", "assay_variant_accession", "data_validity_comment",
    "potential_duplicate", "document_year", "ligand_efficiency",
]

# Close homologs / same-family RTKs for the optional transfer-learning pool.
# EGFR = CHEMBL203. Relatives chosen by kinase-domain sequence similarity:
#   ERBB2/HER2 (CHEMBL1824), ERBB4 (CHEMBL3155), SRC (CHEMBL267),
#   ABL1 (CHEMBL1862), LCK (CHEMBL258), VEGFR2/KDR (CHEMBL279)
KINASE_FAMILY = {
    "CHEMBL203":  "EGFR",
    "CHEMBL1824": "ERBB2",
    "CHEMBL3155": "ERBB4",
    "CHEMBL267":  "SRC",
    "CHEMBL1862": "ABL1",
    "CHEMBL258":  "LCK",
    "CHEMBL279":  "KDR_VEGFR2",
}


def fetch_activities(target_chembl_id: str, sleep: float = 0.35) -> pd.DataFrame:
    rows, offset, limit = [], 0, 1000
    while True:
        url = (
            f"{BASE}/activity.json?target_chembl_id={target_chembl_id}"
            f"&standard_type__in=Ki,IC50,Kd&pchembl_value__gte=3"
            f"&limit={limit}&offset={offset}"
        )
        for attempt in range(4):
            r = requests.get(url, timeout=60)
            if r.status_code == 200:
                break
            time.sleep(2 ** attempt)
        else:
            raise RuntimeError(f"ChEMBL API failed for {url} (status {r.status_code})")
        payload = r.json()
        batch = payload.get("activities", [])
        rows.extend(batch)
        total = payload["page_meta"]["total_count"]
        print(f"  {target_chembl_id}: fetched {len(rows)}/{total}", flush=True)
        if len(rows) >= total or not batch:
            break
        offset += limit
        time.sleep(sleep)
    df = pd.DataFrame(rows)
    if len(df):
        df = df[[c for c in FIELDS if c in df.columns]]
    return df


def fetch_uniprot_sequence(uniprot_id: str) -> str:
    url = f"https://rest.uniprot.org/uniprotkb/{uniprot_id}.fasta"
    r = requests.get(url, timeout=60)
    r.raise_for_status()
    return "".join(line.strip() for line in r.text.splitlines() if not line.startswith(">"))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--target", default="CHEMBL203", help="ChEMBL target id (EGFR = CHEMBL203)")
    ap.add_argument("--out", default="data/raw/egfr_chembl203.csv")
    ap.add_argument("--fetch-kinase-family", action="store_true",
                    help="Also fetch related kinases for transfer-learning pretraining")
    ap.add_argument("--sequence-out", default="data/raw/egfr_P00533.fasta")
    args = ap.parse_args()

    print(f"Fetching activities for {args.target} …")
    df = fetch_activities(args.target)
    df.to_csv(args.out, index=False)
    print(f"Saved {len(df)} rows -> {args.out}")

    if args.fetch_kinase_family:
        frames = []
        for tid, name in KINASE_FAMILY.items():
            if tid == args.target:
                continue
            try:
                d = fetch_activities(tid)
                d["src_target"] = name
                frames.append(d)
            except RuntimeError as e:
                print(f"  WARNING: {e}")
        if frames:
            fam = pd.concat(frames, ignore_index=True)
            out = args.out.replace(".csv", "_kinase_family.csv")
            fam.to_csv(out, index=False)
            print(f"Saved {len(fam)} rows -> {out}")

    print("Fetching EGFR sequence (UniProt P00533) …")
    seq = fetch_uniprot_sequence("P00533")
    kinase_domain = seq[695:1022]  # EGFR kinase domain ≈ residues 696–1022
    with open(args.sequence_out, "w") as f:
        f.write(">sp|P00533|EGFR_HUMAN full length\n" + seq + "\n")
        f.write(">EGFR_kinase_domain residues 696-1022\n" + kinase_domain + "\n")
    print(f"Saved sequence ({len(seq)} aa, kinase domain {len(kinase_domain)} aa) -> {args.sequence_out}")


if __name__ == "__main__":
    main()
