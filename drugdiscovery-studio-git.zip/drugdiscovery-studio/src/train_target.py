"""
One-command auto-trainer for ANY ChEMBL target. Produces a cached Tier A model.

    python src/train_target.py --target CHEMBL4282   # BRAF example

Writes:
  data/targets/<ID>/raw.csv, assay_confidence.csv, clean.csv, split.csv, fp2048.npz
  artifacts/targets/<ID>/ensemble.pkl, metrics.json, status.json (live progress)
"""
import argparse
import json
import os
import subprocess
import sys
import time

ROOT = os.path.join(os.path.dirname(__file__), "..")


def status(out_dir, stage, done=False, error=None):
    st = {"stage": stage, "done": done, "error": error, "ts": time.time()}
    os.makedirs(out_dir, exist_ok=True)
    with open(os.path.join(out_dir, "status.json"), "w") as f:
        json.dump(st, f)
    print(f"[{stage}]", flush=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--target", required=True)
    ap.add_argument("--min-compounds", type=int, default=300)
    args = ap.parse_args()
    tid = args.target.upper()
    PY = sys.executable

    data_dir = os.path.join(ROOT, "data/targets", tid)
    art_dir = os.path.join(ROOT, "artifacts/targets", tid)
    os.makedirs(data_dir, exist_ok=True)
    raw = os.path.join(data_dir, "raw.csv")
    clean = os.path.join(data_dir, "clean.csv")
    split = os.path.join(data_dir, "split.csv")
    cache = os.path.join(data_dir, "fp2048.npz")

    try:
        if not os.path.exists(raw):
            status(art_dir, "downloading activities from ChEMBL")
            subprocess.check_call([PY, os.path.join(ROOT, "src/download_chembl.py"),
                                   "--target", tid, "--out", raw],
                                  cwd=ROOT)
            status(art_dir, "fetching assay confidence scores")
            subprocess.check_call([PY, os.path.join(ROOT, "src/fetch_assay_confidence.py"),
                                   "--activities", raw,
                                   "--out", os.path.join(data_dir, "assay_confidence.csv")],
                                  cwd=ROOT)
        else:
            status(art_dir, "raw data cached, reusing")

        status(art_dir, "cleaning & standardizing molecules")
        subprocess.check_call([
            PY, os.path.join(ROOT, "src/data_prep.py"), "--in", raw, "--out", clean,
            "--assay-confidence", os.path.join(data_dir, "assay_confidence.csv"),
            "--report", os.path.join(data_dir, "cleaning_report.json")], cwd=ROOT)

        n_clean = sum(1 for _ in open(clean)) - 1
        if n_clean < args.min_compounds:
            status(art_dir, f"failed", done=True,
                   error=f"Only {n_clean} clean compounds (< {args.min_compounds}). "
                         f"Not enough public data for a reliable model for this target.")
            return

        status(art_dir, "scaffold splitting")
        subprocess.check_call([PY, os.path.join(ROOT, "src/scaffold_split.py"),
                               "--in", clean, "--out", split], cwd=ROOT)

        status(art_dir, "featurizing (ECFP fingerprints)")
        subprocess.check_call([PY, os.path.join(ROOT, "src/features.py"),
                               "--in", split, "--cache", cache], cwd=ROOT)

        status(art_dir, "training LightGBM ensemble (Tier A)")
        subprocess.check_call([PY, os.path.join(ROOT, "src/tier_a.py"),
                               "--split", split, "--cache", cache,
                               "--out", art_dir, "--n-members", "6"], cwd=ROOT)

        status(art_dir, "done", done=True)
    except subprocess.CalledProcessError as e:
        status(art_dir, "failed", done=True, error=str(e))


if __name__ == "__main__":
    main()
