"""
TIER B — advanced: Graph Neural Network (MPNN over atoms/bonds) conditioned on
a protein target embedding, fused in an MLP head. Uncertainty via MC-Dropout
(T stochastic forward passes at inference).

Supports optional kinase-family pretraining for transfer learning:
  --pretrain data/processed/kinase_family_clean.csv
(pretrains on related kinases, embedding their sequences, then fine-tunes on
EGFR with a lower learning rate).

Usage:
    python src/tier_b.py --split data/processed/egfr_split.csv \
        --fasta data/raw/egfr_P00533.fasta \
        --graph-cache data/processed/graphs.pkl --out artifacts/tier_b
"""
import argparse
import json
import math
import os
import time

import numpy as np
import pandas as pd
import torch
import torch.nn as nn

from evaluate import regression_metrics, uncertainty_diagnostics, format_metrics
from graph_features import (ATOM_DIM, BOND_DIM, load_or_build_graphs)
from protein_embedding import get_target_embedding

torch.set_num_threads(os.cpu_count() or 4)


# ---------------------------------------------------------------- batching
def collate(graphs, idx):
    xs, eis, efs, batch = [], [], [], []
    off = 0
    for b, i in enumerate(idx):
        x, ei, ef = graphs[i]
        n = x.shape[0]
        xs.append(torch.from_numpy(x))
        eis.append(torch.from_numpy(ei) + off)
        efs.append(torch.from_numpy(ef))
        batch.append(torch.full((n,), b, dtype=torch.long))
        off += n
    return (torch.cat(xs), torch.cat(eis, 1), torch.cat(efs), torch.cat(batch))


def scatter_sum(src, index, dim_size):
    out = src.new_zeros((dim_size, src.shape[1]))
    out.index_add_(0, index, src)
    return out


def scatter_max(src, index, dim_size):
    out = src.new_full((dim_size, src.shape[1]), -1e9)
    out.scatter_reduce_(0, index.unsqueeze(-1).expand_as(src), src, reduce="amax")
    return out


# ---------------------------------------------------------------- model
class MPLayer(nn.Module):
    def __init__(self, h):
        super().__init__()
        self.msg = nn.Sequential(nn.Linear(2 * h + h, h), nn.ReLU(), nn.Linear(h, h))
        self.upd = nn.GRUCell(h, h)

    def forward(self, x, edge_index, edge_attr):
        src, dst = edge_index
        m = self.msg(torch.cat([x[src], x[dst], edge_attr], dim=1))
        agg = scatter_sum(m, dst, x.shape[0])
        return self.upd(agg, x)


class AffinityGNN(nn.Module):
    def __init__(self, atom_dim=ATOM_DIM, bond_dim=BOND_DIM, prot_dim=442,
                 h=128, n_layers=3, dropout=0.25):
        super().__init__()
        self.atom_enc = nn.Linear(atom_dim, h)
        self.bond_enc = nn.Linear(bond_dim, h)
        self.layers = nn.ModuleList([MPLayer(h) for _ in range(n_layers)])
        self.prot_proj = nn.Sequential(nn.Linear(prot_dim, 128), nn.LayerNorm(128),
                                       nn.GELU(), nn.Dropout(dropout))
        self.head = nn.Sequential(
            nn.Linear(2 * h + 128, 256), nn.GELU(), nn.Dropout(dropout),
            nn.Linear(256, 128), nn.GELU(), nn.Dropout(dropout),
            nn.Linear(128, 1),
        )

    def encode(self, x, ei, ef, batch, prot):
        h = torch.relu(self.atom_enc(x))
        e = torch.relu(self.bond_enc(ef))
        for layer in self.layers:
            h = h + layer(h, ei, e)                    # residual
        n_graphs = int(batch.max()) + 1
        g = torch.cat([scatter_sum(h, batch, n_graphs) /
                       scatter_sum(torch.ones_like(h), batch, n_graphs).clamp(min=1),
                       scatter_max(h, batch, n_graphs)], dim=1)
        p = self.prot_proj(prot).expand(n_graphs, -1)
        return torch.cat([g, p], dim=1)

    def forward(self, x, ei, ef, batch, prot):
        return self.head(self.encode(x, ei, ef, batch, prot)).squeeze(-1)


# ---------------------------------------------------------------- training
def run_epochs(model, graphs, y, idx, prot, optimizer, loss_fn, batch_size, train=True):
    model.train() if train else model.eval()
    order = np.random.permutation(len(idx)) if train else np.arange(len(idx))
    preds = np.zeros(len(idx), dtype=np.float32)
    tot_loss, nb = 0.0, 0
    ctx = torch.enable_grad() if train else torch.no_grad()
    with ctx:
        for s in range(0, len(idx), batch_size):
            chunk = [idx[j] for j in order[s:s + batch_size]]
            x, ei, ef, bt = collate(graphs, chunk)
            if train:
                optimizer.zero_grad()
            out = model(x, ei, ef, bt, prot)
            loss = loss_fn(out, torch.from_numpy(y[chunk]))
            if train:
                loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(), 2.0)
                optimizer.step()
            tot_loss += loss.item()
            nb += 1
            preds[order[s:s + batch_size]] = out.detach().cpu().numpy()
    return tot_loss / max(nb, 1), preds


def fit(model, graphs, y, tr, va, prot, epochs, lr, batch_size, patience, log_prefix=""):
    opt = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=1e-4)
    loss_fn = nn.SmoothL1Loss(beta=1.0)
    best = {"rmse": np.inf, "state": None, "epoch": -1}
    bad = 0
    for ep in range(1, epochs + 1):
        t0 = time.time()
        tr_loss, _ = run_epochs(model, graphs, y, tr, prot, opt, loss_fn, batch_size, True)
        va_loss, va_pred = run_epochs(model, graphs, y, va, prot, opt, loss_fn, batch_size, False)
        va_rmse = float(np.sqrt(np.mean((va_pred - y[va]) ** 2)))
        if va_rmse < best["rmse"]:
            best = {"rmse": va_rmse,
                    "state": {k: v.detach().clone() for k, v in model.state_dict().items()},
                    "epoch": ep}
            bad = 0
        else:
            bad += 1
        if ep % 5 == 0 or ep == 1:
            print(f"  {log_prefix}epoch {ep:3d}: train_loss={tr_loss:.4f} "
                  f"val_rmse={va_rmse:.4f} ({time.time()-t0:.1f}s)", flush=True)
        if bad >= patience:
            break
    model.load_state_dict(best["state"])
    print(f"  {log_prefix}best val RMSE={best['rmse']:.4f} @ epoch {best['epoch']}")
    return model


@torch.no_grad()
def mc_dropout_predict(model, graphs, idx, prot, batch_size=512, T=30, seed=7):
    model.train()  # keep dropout active; no BatchNorm in this architecture
    torch.manual_seed(seed)
    outs = []
    for _ in range(T):
        preds = np.zeros(len(idx), dtype=np.float32)
        for s in range(0, len(idx), batch_size):
            chunk = idx[s:s + batch_size]
            x, ei, ef, bt = collate(graphs, chunk)
            preds[s:s + batch_size] = model(x, ei, ef, bt, prot).cpu().numpy()
        outs.append(preds)
    outs = np.stack(outs)
    return outs.mean(0), outs.std(0)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--split", required=True)
    ap.add_argument("--fasta", default="data/raw/egfr_P00533.fasta")
    ap.add_argument("--graph-cache", default="data/processed/graphs.pkl")
    ap.add_argument("--out", default="artifacts/tier_b")
    ap.add_argument("--esm", action="store_true")
    ap.add_argument("--hidden", type=int, default=128)
    ap.add_argument("--dropout", type=float, default=0.25)
    ap.add_argument("--epochs", type=int, default=80)
    ap.add_argument("--lr", type=float, default=1e-3)
    ap.add_argument("--batch-size", type=int, default=256)
    ap.add_argument("--patience", type=int, default=12)
    ap.add_argument("--mc-samples", type=int, default=30)
    ap.add_argument("--pretrain", default=None,
                    help="cleaned kinase-family CSV for transfer-learning pretraining")
    ap.add_argument("--pretrain-epochs", type=int, default=25)
    args = ap.parse_args()

    os.makedirs(args.out, exist_ok=True)
    df = pd.read_csv(args.split)
    graphs = load_or_build_graphs(df, args.graph_cache)
    y = df["label"].to_numpy(np.float32)
    split = df["split"].to_numpy()
    tr = np.where(split == "train")[0]
    va = np.where(split == "val")[0]
    te = np.where(split == "test")[0]
    print(f"graphs={len(graphs)}  train={len(tr)} val={len(va)} test={len(te)}")

    prot_emb = get_target_embedding(args.fasta, args.esm)
    prot = torch.from_numpy((prot_emb - prot_emb.mean()) / (prot_emb.std() + 1e-8)).unsqueeze(0)

    model = AffinityGNN(prot_dim=prot.shape[1], h=args.hidden, dropout=args.dropout)
    print(f"parameters: {sum(p.numel() for p in model.parameters()):,}")

    # ---- optional transfer-learning pretraining on kinase family ----
    if args.pretrain:
        pf = pd.read_csv(args.pretrain)
        pgraphs = load_or_build_graphs(pf, args.graph_cache.replace(".pkl", "_kinfam.pkl"))
        py = pf["label"].to_numpy(np.float32)
        pidx = np.arange(len(pf))
        print(f"pretraining on {len(pf)} kinase-family compounds …")
        fit(model, pgraphs, py, pidx, pidx, prot, args.pretrain_epochs, args.lr,
            args.batch_size, args.pretrain_epochs + 1, log_prefix="[pretrain] ")
        args.lr = min(args.lr, 2e-4)  # fine-tune gently
        print(f"fine-tuning on EGFR with lr={args.lr}")

    t0 = time.time()
    fit(model, graphs, y, tr, va, prot, args.epochs, args.lr, args.batch_size,
        args.patience, log_prefix="[egfr] ")
    train_time = time.time() - t0

    # ---- calibrated MC-dropout evaluation ----
    va_mu, va_sd = mc_dropout_predict(model, graphs, va, prot, T=args.mc_samples)
    scale = float(np.sqrt(np.mean((va_mu - y[va]) ** 2)) / max(va_sd.mean(), 1e-6))

    t0 = time.time()
    te_mu, te_sd = mc_dropout_predict(model, graphs, te, prot, T=args.mc_samples)
    infer_time = time.time() - t0
    te_sd_cal = te_sd * scale

    metrics = regression_metrics(y[te], te_mu)
    unc = uncertainty_diagnostics(y[te], te_mu, te_sd_cal)
    va_metrics = regression_metrics(y[va], va_mu)

    print("\n=== TIER B (GNN + protein embedding, MC-dropout) ===")
    print("val :", format_metrics(va_metrics))
    print("test:", format_metrics(metrics))
    print("uncertainty:", {k: round(v, 3) for k, v in unc.items()})
    print(f"train_time={train_time:.1f}s  "
          f"MC-inference={infer_time:.1f}s for {len(te)} mols "
          f"({1000*infer_time/len(te):.2f}s per 1000, T={args.mc_samples})")

    torch.save({"state_dict": model.state_dict(),
                "config": {"prot_dim": int(prot.shape[1]), "h": args.hidden,
                           "dropout": args.dropout},
                "unc_scale": scale, "prot_emb": prot_emb},
               os.path.join(args.out, "gnn.pt"))
    res = {"tier": "B", "model": f"MPNN-GNN(h={args.hidden}) + target emb "
                                 f"({'ESM2' if args.esm else 'lightweight'}) + MC-dropout",
           "val": va_metrics, "test": metrics, "uncertainty": unc,
           "unc_scale": scale, "train_time_s": train_time,
           "mc_infer_s_per_1000": 1000 * infer_time / len(te)}
    with open(os.path.join(args.out, "metrics.json"), "w") as f:
        json.dump(res, f, indent=2)
    pd.DataFrame({
        "inchikey14": df.iloc[te]["inchikey14"].to_numpy(),
        "std_smiles": df.iloc[te]["std_smiles"].to_numpy(),
        "y_true": y[te], "y_pred": te_mu, "uncertainty": te_sd_cal,
    }).to_csv(os.path.join(args.out, "test_predictions.csv"), index=False)


if __name__ == "__main__":
    main()
