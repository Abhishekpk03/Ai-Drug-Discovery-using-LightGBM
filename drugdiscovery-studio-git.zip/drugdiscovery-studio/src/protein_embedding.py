"""
Protein target embedding for Tier B.

Default (zero-download): composition + physicochemical descriptor vector of the
kinase-domain sequence (~441 dims), projected by a learned linear layer inside
the GNN fusion head.

Optional (best quality): ESM2 pretrained protein-LM embedding. Requires
`pip install transformers` and downloads facebook/esm2_t6_8M_UR50D (~35 MB).
Use `--esm` to enable; falls back to the lightweight vector if unavailable.

Why ESM2 is the viable option at <2k compounds: the protein encoder is frozen
and pretrained on ~250M sequences, so the GNN never has to learn protein
representation from scarce affinity data.
"""
import argparse
import re

import numpy as np

AA = "ARNDCQEGHILKMFPSTWYV"
AA_SET = set(AA)

# Per-residue properties used for physicochemical summaries
_KD = dict(zip(AA, [1.8, -4.5, -3.5, -3.5, 2.5, -3.5, -3.5, -0.4, -3.2, 4.5,
                    3.8, 1.9, -3.5, -1.6, -3.5, -0.8, -0.7, 4.2, -0.9, -1.3]))  # Kyte-Doolittle
_MW = dict(zip(AA, [174.2, 115.1, 132.1, 133.1, 121.2, 146.2, 147.1, 75.1,
                    155.2, 131.2, 131.2, 146.2, 149.2, 165.2, 115.1, 105.1,
                    119.1, 204.2, 181.2, 117.1]))
_PI = dict(zip(AA, [10.76, 5.41, 5.41, 2.77, 5.02, 5.65, 3.22, 5.97, 7.59,
                    5.98, 5.98, 9.74, 5.74, 5.48, 6.30, 5.68, 5.60, 5.89, 5.66, 6.00]))


def read_kinase_domain(fasta_path: str) -> str:
    seqs = {}
    name, buf = None, []
    with open(fasta_path) as f:
        for line in f:
            line = line.strip()
            if line.startswith(">"):
                if name is not None:
                    seqs[name] = "".join(buf)
                name, buf = line[1:], []
            else:
                buf.append(line)
        if name is not None:
            seqs[name] = "".join(buf)
    for k in seqs:
        if "kinase_domain" in k:
            return seqs[k]
    return list(seqs.values())[0]


def lightweight_embedding(seq: str) -> np.ndarray:
    """Unnormalized k-mer (1&2) composition + physicochemical summaries."""
    seq = "".join(c for c in seq.upper() if c in AA_SET) or "A"
    n = len(seq)
    feats = [np.array([(seq.count(a) or 0) / n for a in AA], dtype=np.float32)]  # 20
    di = np.zeros((20, 20), dtype=np.float32)
    for a, b in zip(seq[:-1], seq[1:]):
        di[AA.index(a), AA.index(b)] += 1
    di /= max(n - 1, 1)
    feats.append(di.ravel())  # 400
    kd = np.array([_KD[a] for a in seq])
    mw = np.array([_MW[a] for a in seq])
    pi = np.array([_PI[a] for a in seq])
    props = np.array([
        *np.percentile(kd, [0, 25, 50, 75, 100]), kd.var(),
        *np.percentile(mw, [0, 25, 50, 75, 100]), mw.var(),
        *np.percentile(pi, [0, 25, 50, 75, 100]), pi.var(),
        n / 1000.0,
        sum(seq.count(a) for a in "RKDEH") / n,                      # charged frac
        sum(seq.count(a) for a in "AILMFWV") / n,                     # hydrophobic frac
    ], dtype=np.float32)
    feats.append(props)  # 22*? -> 19 + 3 = ~22
    return np.concatenate(feats).astype(np.float32)  # 20 + 400 + 21 = 441 dims


def esm2_embedding(seq: str, model_name="facebook/esm2_t6_8M_UR50D"):
    """Mean-pooled ESM2 (last hidden state) embedding; needs transformers+torch."""
    import torch
    from transformers import AutoTokenizer, AutoModel
    tok = AutoTokenizer.from_pretrained(model_name)
    model = AutoModel.from_pretrained(model_name)
    model.eval()
    with torch.no_grad():
        inputs = tok(seq, return_tensors="pt", truncation=True, max_length=1024)
        out = model(**inputs).last_hidden_state  # (1, L, D)
        emb = out.mean(dim=1).squeeze(0).numpy().astype(np.float32)
    return emb


def get_target_embedding(fasta_path: str, use_esm: bool = False) -> np.ndarray:
    seq = read_kinase_domain(fasta_path)
    if use_esm:
        try:
            emb = esm2_embedding(seq)
            print(f"ESM2 embedding dim={emb.shape[0]}")
            return emb
        except Exception as e:
            print(f"WARNING: ESM2 unavailable ({e}); falling back to lightweight embedding")
    emb = lightweight_embedding(seq)
    print(f"lightweight protein embedding dim={emb.shape[0]}")
    return emb


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--fasta", default="data/raw/egfr_P00533.fasta")
    ap.add_argument("--esm", action="store_true")
    ap.add_argument("--out", default="artifacts/target_embedding.npy")
    args = ap.parse_args()
    emb = get_target_embedding(args.fasta, args.esm)
    np.save(args.out, emb)
    print(f"saved {emb.shape} -> {args.out}")
