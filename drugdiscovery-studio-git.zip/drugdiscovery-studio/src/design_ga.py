"""
De novo molecule designer: a genetic algorithm that evolves molecules to
maximize (predicted affinity - uncertainty penalty + drug-likeness reward)
for a given trained Tier A target model.

Honest scope: this is virtual optimization under the model — novel molecules it
proposes are hypotheses to be validated, not guaranteed drugs. Novelty is
checked against the training set (InChIKey + scaffold).

Usage:
    python src/design_ga.py --target CHEMBL203 --n 15 --generations 25
"""
import argparse
import json
import pickle
import random

import numpy as np
import pandas as pd
from rdkit import Chem, RDLogger
from rdkit.Chem import QED

RDLogger.DisableLog("rdApp.*")

# small medicinally-reasonable substituents for "grow" mutations (SMILES + atom map)
FRAGMENTS = ["C", "CC", "O", "OC", "N", "F", "Cl", "C(F)(F)F", "C#N", "c1ccccc1", "OCC", "N(C)C", "S(C)(=O)=O"]
ELEMENTS = {6: [7, 8, 16, 9, 17], 7: [6, 8, 16], 8: [6, 7, 16], 16: [6, 7, 8], 9: [17], 17: [9]}


def mutate(smiles, rng):
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        return None
    rw = Chem.RWMol(mol)
    op = rng.choice(["element", "grow", "delete", "grow_ring"])
    atoms = list(rw.GetAtoms())
    if op == "element":
        heavy = [a for a in atoms if a.GetAtomicNum() in ELEMENTS]
        if not heavy:
            return None
        a = rng.choice(heavy)
        new = rng.choice(ELEMENTS[a.GetAtomicNum()])
        try:
            a.SetAtomicNum(new)
            a.SetFormalCharge(0)
        except Exception:
            return None
    elif op in ("grow", "grow_ring"):
        eligible = []
        for a in atoms:
            if a.GetDegree() <= (2 if op == "grow_ring" else 3) and a.GetTotalNumHs() >= 1:
                eligible.append(a)
        if not eligible:
            return None
        a = rng.choice(eligible)
        frag = rng.choice(FRAGMENTS) if op == "grow" else "C1CC1"
        fm = Chem.MolFromSmiles(frag)
        if fm is None:
            return None
        combo = Chem.rdmolops.CombineMols(rw.GetMol(), fm)
        rw = Chem.RWMol(combo)
        bond_type = Chem.BondType.AROMATIC if a.GetIsAromatic() else Chem.BondType.SINGLE
        try:
            rw.AddBond(a.GetIdx(), mol.GetNumAtoms(), bond_type)
        except Exception:
            return None
        if op == "grow_ring":
            pass
    elif op == "delete":
        leaves = [a for a in atoms if a.GetDegree() == 1 and a.GetAtomicNum() > 1]
        if not leaves:
            return None
        rw.RemoveAtom(rng.choice(leaves).GetIdx())
    try:
        Chem.SanitizeMol(rw.GetMol())
        nxt = Chem.MolToSmiles(rw.GetMol())
        if 3 <= Chem.MolFromSmiles(nxt).GetNumHeavyAtoms() <= 45:
            return nxt
    except Exception:
        return None
    return None


def key_of(smiles):
    ik = Chem.MolToInchi(Chem.MolFromSmiles(smiles))
    return Chem.InchiToInchiKey(ik)[:14] if ik else smiles


def design(split_csv, art_dir, n=15, generations=25, pop_size=64, seed=0):
    import sys, os
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    from features import featurize
    from scaffold_split import murcko_scaffold

    rng = random.Random(seed)
    with open(os.path.join(art_dir, "ensemble.pkl"), "rb") as f:
        d = pickle.load(f)
    models, unc_scale = d["models"], d["unc_scale"]
    train = pd.read_csv(split_csv)
    train_keys = set(train["inchikey14"])
    train_scaffolds = set(train["scaffold"])

    def score(smiles_list):
        X, bad = featurize(smiles_list)
        preds = np.stack([m.predict(X) for m in models])
        return preds.mean(0), preds.std(0) * unc_scale, bad

    seeds = train.sort_values("label", ascending=False)["std_smiles"].head(200).tolist()
    pop = [rng.choice(seeds) for _ in range(pop_size)]

    best = {}  # key -> record
    for gen in range(generations):
        mu, unc, _ = score(pop)
        pool = {}
        for smi, m, u in zip(pop, mu, unc):
            qed = QED.qed(Chem.MolFromSmiles(smi))
            fit = float(m) - 0.4 * float(u) + 0.5 * qed
            pool[smi] = (fit, float(m), float(u), qed)
        ranked = sorted(pool.items(), key=lambda kv: -kv[1][0])
        elites = [smi for smi, _ in ranked[: len(ranked) // 2]]
        for smi, (fit, m, u, qed) in ranked[:8]:
            k = key_of(smi)
            best[k] = {"smiles": smi, "pred_pchembl": round(m, 3),
                       "pred_ic50_nM": round(min(10 ** (9 - m), 1e8), 2),
                       "uncertainty": round(u, 3), "confidence": round(1 / (1 + u), 4),
                       "qed": round(float(qed), 3),
                       "novel_compound": k not in train_keys}
        children = []
        while len(children) < pop_size:
            parent = rng.choice(elites) if rng.random() < 0.8 else rng.choice(seeds)
            smi = parent
            for _ in range(3):
                m2 = mutate(parent, rng)
                if m2 and m2 != parent:
                    smi = m2
                    break
            children.append(smi)
        pop = children
        if (gen + 1) % 5 == 0:
            print(f"  gen {gen+1}: best fitness {ranked[0][1][0]:.3f}, pool={len(best)}", flush=True)

    out = list(best.values())
    for r in out:
        r["novel_scaffold"] = murcko_scaffold(r["smiles"]) not in train_scaffolds
    out.sort(key=lambda r: -(r["pred_pchembl"] - 0.4 * r["uncertainty"] + 0.5 * r["qed"]))
    return out[:n]


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--split", required=True, help="per-target split CSV")
    ap.add_argument("--art-dir", required=True, help="dir containing ensemble.pkl")
    ap.add_argument("--n", type=int, default=15)
    ap.add_argument("--generations", type=int, default=25)
    args = ap.parse_args()
    res = design(args.split, args.art_dir, n=args.n, generations=args.generations)
    print(json.dumps(res, indent=2))
