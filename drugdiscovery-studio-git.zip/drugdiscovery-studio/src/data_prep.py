"""
Clean & standardize raw ChEMBL activity data.

Steps:
  1. Assay-level filters: exact '=' relations, human protein, confidence >= 4,
     exclusion of known mutant-EGFR assays (keyword-based).
  2. Structure standardization (RDKit): salt/solvent stripping, neutralization,
     canonical tautomer, canonical SMILES + 14-char InChIKey as the dedup key.
  3. Unit standardization: everything -> pChEMBL = -log10(affinity in M).
  4. Deduplication: per-compound median across assays; compounds with
     conflicting measurements (spread > --max-spread log units) are dropped.

Usage:
    python src/data_prep.py --in data/raw/egfr_chembl203.csv \
        --out data/processed/egfr_clean.csv --report data/processed/cleaning_report.json
"""
import argparse
import json

import numpy as np
import pandas as pd
from rdkit import Chem, RDLogger
from rdkit.Chem.MolStandardize import rdMolStandardize

RDLogger.DisableLog("rdApp.*")

# Curated keywords that flag mutant/variant-EGFR assays in assay descriptions.
MUTANT_KEYWORDS = [
    "mutant", "mutation", "l858r", "t790m", "c797s", "g719s", "g719c", "l861q",
    "d746", "del19", "exon 19 deletion", "exon 20 insertion", "e746_a750",
    "resistant", "v769", "h773", "s768i", "d770_n771",
]

_frag_parent = rdMolStandardize.FragmentParent
_uncharger = rdMolStandardize.Uncharger()
_tautomerizer = rdMolStandardize.TautomerEnumerator()


def standardize_smiles(smiles: str):
    """Return (canonical_smiles, inchikey14) or None on failure."""
    try:
        mol = Chem.MolFromSmiles(smiles)
        if mol is None:
            return None
        mol = _frag_parent(mol)                      # strip salts/solvents
        mol = _uncharger.uncharge(mol)               # neutralize
        mol = _tautomerizer.Canonicalize(mol)        # canonical tautomer
        for atom in mol.GetAtoms():                  # drop isotope labels
            atom.SetIsotope(0)
        can_smi = Chem.MolToSmiles(mol, isomericSmiles=False)
        ik = Chem.MolToInchiKey(mol)
        if not ik:
            return None
        return can_smi, ik[:14]
    except Exception:
        return None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--in", dest="inp", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--report", default="data/processed/cleaning_report.json")
    ap.add_argument("--assay-confidence", default="data/raw/assay_confidence.csv",
                    help="CSV from fetch_assay_confidence.py (assay_chembl_id, assay_confidence_score)")
    ap.add_argument("--min-confidence", type=float, default=4)
    ap.add_argument("--max-spread", type=float, default=1.0,
                    help="Drop compounds whose replicate affinities span more than this (log10 units)")
    ap.add_argument("--keep-mutant-assays", action="store_true")
    args = ap.parse_args()

    rep = {}
    df = pd.read_csv(args.inp)
    rep["n_raw_rows"] = len(df)

    # ---------- 1. assay-level filters ----------
    n = len(df)
    rel = df["standard_relation"].fillna("=")
    df = df[rel.isin(["=", "'='"])].copy()
    rep["drop_non_exact_relation"] = n - len(df)

    n = len(df)
    df = df[df["target_organism"] == "Homo sapiens"].copy()
    rep["drop_non_human"] = n - len(df)

    n = len(df)
    if "data_validity_comment" in df.columns:
        df = df[df["data_validity_comment"].isna()].copy()
    rep["drop_data_validity_flagged"] = n - len(df)

    n = len(df)
    if "potential_duplicate" in df.columns:
        df = df[~df["potential_duplicate"].fillna(False).astype(bool)].copy()
    rep["drop_potential_duplicates"] = n - len(df)

    # merge ChEMBL assay confidence score
    try:
        conf = pd.read_csv(args.assay_confidence)
        df = df.merge(conf[["assay_chembl_id", "assay_confidence_score"]],
                      on="assay_chembl_id", how="left")
        n = len(df)
        df = df[df["assay_confidence_score"].fillna(0) >= args.min_confidence].copy()
        rep["drop_low_confidence_assay"] = n - len(df)
    except FileNotFoundError:
        print(f"WARNING: {args.assay_confidence} not found; skipping confidence filter")
        rep["drop_low_confidence_assay"] = "skipped"

    if not args.keep_mutant_assays:
        n = len(df)
        pat = "|".join(MUTANT_KEYWORDS)
        kw = df["assay_description"].fillna("").str.lower().str.contains(pat, regex=True)
        if "assay_variant_mutation" in df.columns:
            structured = df["assay_variant_mutation"].notna()
        else:
            structured = pd.Series(False, index=df.index)
        is_mut = kw | structured
        rep["drop_mutant_assay_rows"] = int(is_mut.sum())
        df = df[~is_mut].copy()

    # label = pchembl (guaranteed present by the download query), clipped to sane range
    df["label"] = df["pchembl_value"].astype(float).clip(3.0, 11.0)
    rep["after_assay_filters"] = len(df)

    # ---------- 2. structure standardization ----------
    uniq = df["canonical_smiles"].unique()
    smi_map = {}
    for s in uniq:
        res = standardize_smiles(s)
        if res is not None:
            smi_map[s] = res
    before = len(df)
    df = df[df["canonical_smiles"].isin(smi_map)].copy()
    df["std_smiles"] = df["canonical_smiles"].map(lambda s: smi_map[s][0])
    df["inchikey14"] = df["canonical_smiles"].map(lambda s: smi_map[s][1])
    rep["drop_unparseable_smiles"] = before - len(df)

    # ---------- 3. deduplicate ----------
    agg = (
        df.groupby("inchikey14")
        .agg(
            std_smiles=("std_smiles", "first"),
            label=("label", "median"),
            n_measurements=("label", "size"),
            spread=("label", lambda x: float(x.max() - x.min())),
            n_assays=("assay_chembl_id", "nunique"),
            best_type=("standard_type", lambda x: x.mode().iloc[0]),
        )
        .reset_index()
    )
    before = len(agg)
    agg = agg[agg["spread"] <= args.max_spread].reset_index(drop=True)
    rep["drop_conflicting_compounds"] = before - len(agg)
    rep["n_unique_compounds"] = len(agg)
    rep["label_stats"] = {
        "mean": float(agg["label"].mean()), "std": float(agg["label"].std()),
        "min": float(agg["label"].min()), "max": float(agg["label"].max()),
    }

    agg.to_csv(args.out, index=False)
    with open(args.report, "w") as f:
        json.dump(rep, f, indent=2)
    print(json.dumps(rep, indent=2))


if __name__ == "__main__":
    main()
