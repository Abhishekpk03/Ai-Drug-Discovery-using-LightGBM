"""
Fast batched inference on new molecules for either tier, with uncertainty.

  Fingerprints/graphs are computed once (cached to disk) — scoring thousands of
  candidates is then a few batched forward passes.

Usage:
    # score a file with one canonical SMILES per line (or a CSV with 'smiles')
    python src/inference.py --tier A --smiles candidates.smi --out scored.csv
    python src/inference.py --tier B --smiles candidates.smi --out scored.csv

    # benchmark scoring speed on N molecules (drawn from the processed data)
    python src/inference.py --tier A --benchmark 10000
"""
import argparse
import pickle
import time

import numpy as np
import pandas as pd
import torch

from graph_features import load_or_build_graphs
from features import featurize
from tier_a import ensemble_predict
from tier_b import AffinityGNN, collate


def load_tier_a(path="artifacts/tier_a/ensemble.pkl"):
    with open(path, "rb") as f:
        d = pickle.load(f)
    return d["models"], d["unc_scale"]


def load_tier_b(path="artifacts/tier_b/gnn.pt"):
    ckpt = torch.load(path, map_location="cpu", weights_only=False)
    cfg = ckpt["config"]
    model = AffinityGNN(prot_dim=cfg["prot_dim"], h=cfg["h"], dropout=cfg["dropout"])
    model.load_state_dict(ckpt["state_dict"])
    prot = torch.from_numpy(
        (ckpt["prot_emb"] - ckpt["prot_emb"].mean()) / (ckpt["prot_emb"].std() + 1e-8)
    ).unsqueeze(0).float()
    return model, prot, ckpt["unc_scale"]


def read_smiles(path):
    if path.endswith(".csv"):
        df = pd.read_csv(path)
        col = "smiles" if "smiles" in df.columns else df.columns[0]
        return df[col].astype(str).tolist()
    out = []
    with open(path) as f:
        for line in f:
            s = line.split()[0].strip()
            if s and s.lower() != "smiles":
                out.append(s)
    return out


def score_tier_a(smiles, mc=False):
    models, scale = load_tier_a()
    X, bad = featurize(smiles)
    mu, sd = ensemble_predict(models, X)
    return mu, sd * scale, bad


def score_tier_b(smiles, mc_samples=30):
    model, prot, scale = load_tier_b()
    tmp = pd.DataFrame({"std_smiles": smiles, "inchikey14": [str(i) for i in range(len(smiles))]})
    graphs = load_or_build_graphs(tmp, "/tmp/_infer_graphs.pkl")
    idx = np.arange(len(graphs))
    outs = []
    model.train()
    for _ in range(mc_samples):
        preds = np.zeros(len(idx), dtype=np.float32)
        for s in range(0, len(idx), 512):
            chunk = idx[s:s + 512]
            x, ei, ef, bt = collate(graphs, chunk)
            with torch.no_grad():
                preds[s:s + 512] = model(x, ei, ef, bt, prot).numpy()
        outs.append(preds)
    outs = np.stack(outs)
    return outs.mean(0), outs.std(0) * scale, []


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tier", choices=["A", "B"], required=True)
    ap.add_argument("--smiles", default=None, help=".smi/.txt/.csv file of SMILES")
    ap.add_argument("--out", default=None)
    ap.add_argument("--benchmark", type=int, default=None,
                    help="benchmark scoring on N molecules from the processed dataset")
    ap.add_argument("--no-uncertainty", action="store_true",
                    help="single forward pass (no MC-dropout / single ensemble member)")
    args = ap.parse_args()

    if args.benchmark:
        df = pd.read_csv("data/processed/egfr_split.csv")
        smiles = df["std_smiles"].tolist()
        reps = int(np.ceil(args.benchmark / len(smiles)))
        smiles = (smiles * reps)[: args.benchmark]
        t0 = time.time()
        if args.tier == "A":
            X, _ = featurize(smiles)
            t_feat = time.time() - t0
            models, scale = load_tier_a()
            t0 = time.time()
            if args.no_uncertainty:
                mu = models[0].predict(X)
                sd = np.zeros_like(mu)
            else:
                mu, sd = ensemble_predict(models, X)
            t_pred = time.time() - t0
        else:
            t_feat = 0.0
            models_b, prot, scale = load_tier_b()
            tmp = pd.DataFrame({"std_smiles": smiles,
                                "inchikey14": [str(i) for i in range(len(smiles))]})
            t0 = time.time()
            graphs = load_or_build_graphs(tmp, "/tmp/_bench_graphs.pkl")
            t_feat = time.time() - t0
            idx = np.arange(len(graphs))
            T = 1 if args.no_uncertainty else 30
            models_b.train()
            t0 = time.time()
            for _ in range(T):
                for s in range(0, len(idx), 512):
                    chunk = idx[s:s + 512]
                    x, ei, ef, bt = collate(graphs, chunk)
                    with torch.no_grad():
                        models_b(x, ei, ef, bt, prot)
            t_pred = time.time() - t0
        print(f"[Tier {args.tier}] N={len(smiles)}")
        print(f"  featurization : {t_feat:.2f}s total ({1000*t_feat/len(smiles)*1000:.1f} ms per 1000 mols)")
        print(f"  scoring       : {t_pred:.2f}s total ({1000*t_pred/len(smiles)*1000:.1f} ms per 1000 mols, "
              f"{'with' if not args.no_uncertainty else 'without'} uncertainty)")
        return

    smiles = read_smiles(args.smiles)
    if args.tier == "A":
        mu, sd, bad = score_tier_a(smiles)
    else:
        mu, sd, bad = score_tier_b(smiles)
    ic50_nM = 10 ** (9 - mu)
    out = pd.DataFrame({"smiles": smiles, "pred_pChEMBL": np.round(mu, 3),
                        "pred_IC50_nM": np.round(ic50_nM, 2),
                        "uncertainty_pChEMBL": np.round(sd, 3),
                        "confidence": np.round(1 / (1 + sd), 4)})
    out = out.sort_values("pred_pChEMBL", ascending=False)
    out.to_csv(args.out, index=False)
    print(f"scored {len(out)} molecules (failed: {len(bad)}) -> {args.out}")
    print(out.head(10).to_string(index=False))


if __name__ == "__main__":
    main()
