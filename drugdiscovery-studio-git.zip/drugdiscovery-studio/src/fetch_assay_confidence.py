"""
Fetch per-assay confidence scores from ChEMBL /assay endpoint for all assays
appearing in a downloaded activities CSV, and save a mapping table.
"""
import argparse, time, json
import pandas as pd, requests

BASE = "https://www.ebi.ac.uk/chembl/api/data"

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--activities", required=True)
    ap.add_argument("--out", default="data/raw/assay_confidence.csv")
    args = ap.parse_args()
    ids = pd.read_csv(args.activities, usecols=["assay_chembl_id"])["assay_chembl_id"].dropna().unique().tolist()
    print(f"{len(ids)} unique assays")
    rows = []
    CH = 100
    for i in range(0, len(ids), CH):
        chunk = ids[i:i+CH]
        url = f"{BASE}/assay.json?assay_chembl_id__in={','.join(chunk)}&limit=1000"
        for attempt in range(4):
            try:
                r = requests.get(url, timeout=60)
                if r.status_code == 200:
                    break
            except Exception:
                pass
            time.sleep(2**attempt)
        payload = r.json()
        for a in payload.get("assays", []):
            rows.append({"assay_chembl_id": a["assay_chembl_id"],
                         "assay_confidence_score": a.get("confidence_score"),
                         "assay_type_detail": a.get("assay_type"),
                         "assay_organism": a.get("assay_organism")})
        if (i // CH) % 10 == 0:
            print(f"  {min(i+CH, len(ids))}/{len(ids)}", flush=True)
        time.sleep(0.25)
    pd.DataFrame(rows).to_csv(args.out, index=False)
    print(f"saved -> {args.out}")

if __name__ == "__main__":
    main()
