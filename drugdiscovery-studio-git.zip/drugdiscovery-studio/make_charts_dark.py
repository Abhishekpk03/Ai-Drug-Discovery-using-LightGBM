"""Regenerate charts with the deck's dark theme (transparent bg, light text)."""
import json

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

TXT, SUB, GRID = "#dbe7f3", "#8ea3b5", "#26344a"
plt.rcParams.update({
    "font.family": "DejaVu Sans", "font.size": 13,
    "axes.edgecolor": GRID, "axes.labelcolor": TXT, "axes.titlecolor": TXT,
    "xtick.color": SUB, "ytick.color": SUB, "text.color": TXT,
    "axes.facecolor": "none", "figure.facecolor": "none",
    "axes.grid": True, "grid.color": GRID, "grid.linewidth": 0.6, "grid.alpha": 0.55,
    "legend.frameon": False,
})
SKY, AMBER, GREEN, RED = "#38bdf8", "#f59e0b", "#34d399", "#f87171"

A = pd.read_csv("artifacts/tier_a/test_predictions.csv")
B = pd.read_csv("artifacts/tier_b/test_predictions.csv")
ma = json.load(open("artifacts/tier_a/metrics.json"))
mb = json.load(open("artifacts/tier_b/metrics.json"))


def save(fig, name):
    fig.savefig(f"artifacts/dark_{name}.png", dpi=170, transparent=True, bbox_inches="tight")
    plt.close(fig)


# 1 scatter
fig, ax = plt.subplots(figsize=(6.2, 5))
sc = ax.scatter(A["y_true"], A["y_pred"], c=A["uncertainty"], cmap="RdYlGn_r", s=16, alpha=0.8, edgecolors="none")
lims = [3.5, 11.5]
ax.plot(lims, lims, "--", color=SUB, lw=1.1, label="perfect")
ax.plot(lims, [l - 1 for l in lims], ":", color=SUB, lw=1)
ax.plot(lims, [l + 1 for l in lims], ":", color=SUB, lw=1, label="±1 log")
ax.set_xlim(lims); ax.set_ylim(lims)
ax.set_xlabel("True potency (pChEMBL)"); ax.set_ylabel("Predicted potency")
ax.set_title(f"Unseen-chemistry test:  R²={ma['test']['r2']:.2f}   ρ={ma['test']['spearman']:.2f}", fontsize=12.5)
cb = fig.colorbar(sc, ax=ax); cb.set_label("uncertainty")
cb.ax.yaxis.set_tick_params(color=SUB); cb.outline.set_edgecolor(GRID)
plt.setp(plt.getp(cb.ax.axes, 'yticklabels'), color=SUB)
cb.set_label("uncertainty", color=SUB)
ax.legend(loc="lower right", fontsize=10)
save(fig, "scatter")

# 2 metrics comparison
metrics = [("RMSE ↓", "rmse"), ("MAE ↓", "mae"), ("R² ↑", "r2"), ("Spearman ρ ↑", "spearman")]
x = np.arange(len(metrics)); w = 0.36
va = [ma["test"][k] for _, k in metrics]; vb = [mb["test"][k] for _, k in metrics]
fig, ax = plt.subplots(figsize=(7.2, 4.2))
ax.bar(x - w/2, va, w, label="Tier A — LightGBM ×7 (ours)", color=SKY)
ax.bar(x + w/2, vb, w, label="Tier B — GNN", color=AMBER)
for xi, (a, b) in zip(x, zip(va, vb)):
    ax.text(xi - w/2, a + 0.03, f"{a:.2f}", ha="center", fontsize=10, fontweight="bold", color=TXT)
    ax.text(xi + w/2, b + 0.03, f"{b:.2f}", ha="center", fontsize=10, color=SUB)
ax.set_xticks(x); ax.set_xticklabels([m for m, _ in metrics])
ax.set_ylim(0, 1.12); ax.legend(fontsize=10, loc="upper right")
ax.set_title("Tier A wins at this data scale", fontsize=12.5)
save(fig, "metrics")

# 3 funnel
rep = json.load(open("data/processed/cleaning_report.json"))
stages = ["Raw ChEMBL rows", "After QC filters", "Mutant assays removed", "Structures standardized", "Unique clean compounds"]
vals = [rep["n_raw_rows"], rep["n_raw_rows"] - rep["drop_potential_duplicates"], rep["after_assay_filters"],
        rep["after_assay_filters"] - rep["drop_unparseable_smiles"], rep["n_unique_compounds"]]
fig, ax = plt.subplots(figsize=(7.2, 4.0))
cols = [SKY, "#2f9fd8", "#2783bb", "#1f679e", "#174b81"][::-1]
bars = ax.barh(stages[::-1], vals[::-1], color=cols, height=0.62)
for b, v in zip(bars, vals[::-1]):
    ax.text(v + 160, b.get_y() + b.get_height()/2, f"{v:,}", va="center", fontsize=11, fontweight="bold", color=TXT)
ax.set_xlim(0, max(vals) * 1.2); ax.grid(axis="y", alpha=0)
ax.set_title("20,949 raw rows → 8,604 trusted labels", fontsize=12.5)
save(fig, "funnel")

# 4 uncertainty quartiles
q = pd.qcut(A["uncertainty"], 4, labels=["Q1\nmost\nconfident", "Q2", "Q3", "Q4\nleast\nconfident"])
errs = (A["y_true"] - A["y_pred"]).abs()
grp = errs.groupby(q, observed=True).mean()
fig, ax = plt.subplots(figsize=(6.0, 4.1))
ax.bar(grp.index, grp.values, color=[GREEN, "#8fbf6f", AMBER, RED], width=0.62)
for i, v in enumerate(grp.values):
    ax.text(i, v + 0.012, f"{v:.2f}", ha="center", fontweight="bold", fontsize=12, color=TXT)
ax.set_ylabel("mean |error| (pChEMBL)"); ax.grid(axis="x", alpha=0)
ax.set_title("Low confidence = bigger error  ✓ signal works", fontsize=12.5)
save(fig, "uncertainty")
print("dark charts done")
