<div align="center">

# 🧬 DrugDiscovery Studio

**Predict → Screen → Design drug molecules for any human protein — in one web app**

[![Python](https://img.shields.io/badge/Python-3.10%2B-3776AB?logo=python&logoColor=white)](https://python.org)
[![RDKit](https://img.shields.io/badge/RDKit-cheminformatics-009688)](https://www.rdkit.org)
[![LightGBM](https://img.shields.io/badge/LightGBM-ensemble-025E8C)](https://lightgbm.readthedocs.io)
[![PyTorch](https://img.shields.io/badge/PyTorch-GNN%20%28Tier%20B%29-EE4C2C?logo=pytorch&logoColor=white)](https://pytorch.org)
[![Flask](https://img.shields.io/badge/UI-Flask%20web%20app-000000?logo=flask&logoColor=white)](https://flask.palletsprojects.com)
[![Data](https://img.shields.io/badge/Data-ChEMBL%20%2B%20UniProt-F59E0B)](https://www.ebi.ac.uk/chembl/)
[![License](https://img.shields.io/badge/License-MIT-34D399)](LICENSE)

*Trained on public experimental data · honest scaffold-split evaluation · per-molecule uncertainty · de-novo molecule design*

</div>

---

## ✨ What is this?

A drug costs **~10 years and $1–2B** to develop, most of it spent lab-testing molecules that fail — out of a **~10⁶⁰**-molecule search space. DrugDiscovery Studio flips the funnel: it learns from **existing public experiments** which molecules are worth testing, ranks them in milliseconds, flags when *not* to trust a prediction, and can even **invent new candidates**.

For any human protein you name — EGFR, BRAF, CDK9, JAK2, DRD2… — the app **automatically** finds it in UniProt/ChEMBL, downloads and curates its binding data, trains a model (**~4 minutes**), shows you its exam scores, and puts it to work:

| | | |
|---|---|---|
| 🎯 **Target Hub** | Type any protein → auto-train a model from live public data | ~4 min / target |
| 🧪 **Screen** | Paste/upload up to 10,000 SMILES → ranked potency + confidence | ~0.5 s / 1k mols |
| 🧬 **Design** | Genetic algorithm evolves **novel** drug-like candidates | ~60–90 s / 15 mols |

> **Not oversold:** this is a *decision-support* tool for ranking binders. It does not — and cannot — prove a molecule treats a disease. See [Limitations](#-limitations--disclaimer).

---

## 🚀 Highlights

- **Real data, real curation** — ChEMBL 37 via live API; salts stripped, duplicates merged, mutant assays excluded, conflicting measurements dropped (EGFR: 20,949 raw rows → **8,604 trusted labels**)
- **Honest evaluation** — Bemis–Murcko **scaffold split**: the test set contains *only* chemotypes never seen in training. Reported metrics are a lower bound, not marketing
- **Two model tiers, A/B-tested** — Tier A: ECFP + LightGBM ×7 ensemble (production). Tier B: graph neural network + protein embedding (research; transfer-learning-ready)
- **Uncertainty that works** — ensemble disagreement, calibration-checked: best-confidence quartile MAE 0.51 vs worst 0.77
- **Reproduces clinical pharmacology** — correctly ranks approved EGFR drugs, including predicting *osimertinib* as weak on **wild-type** EGFR (it is mutant-selective — exactly the drug's design rationale)
- **Protein-centric** — 20+ targets pre-trainable; when a new disease maps to a trained protein, screening starts the same afternoon (protein-level repurposing)
- **Fast** — fingerprint 1k mols in ~0.2 s; score 1k with full uncertainty in ~0.34 s (≈100k compounds in 30 s)
- **Docker-ready** — deploy to Hugging Face Spaces / Render / any VM in minutes

---

## 🧠 Architecture

```
                        ┌──────────────────────────────────────────────────────┐
                        │                DATA (public, live APIs)              │
                        │   UniProt (target resolution)   ChEMBL 37 (assays)   │
                        └───────────────┬──────────────────┬───────────────────┘
                                        │                  │
                                gene/protein name    Ki / Kd / IC50 rows
                                        │                  │
                        ┌───────────────▼──────────────────▼───────────────────┐
                        │                    CURATION                         │
                        │  salt strip · neutralize · canonical tautomer       │
                        │  mutant-assay exclusion · duplicate merge           │
                        │  conflict filter (>1 log spread dropped)            │
                        └───────────────┬─────────────────────────────────────┘
                                        │ 8,604 trusted labels (EGFR)
                        ┌───────────────▼─────────────────────────────────────┐
                        │        HONEST SPLIT — Bemis–Murcko scaffolds        │
                        │   train 80% · val 10% · test 10% (novel chemotypes) │
                        └───────┬──────────────────────────┬──────────────────┘
                                │                          │
                 ┌──────────────▼────────────┐  ┌──────────▼───────────────────┐
                 │  TIER A  (production) 🚀  │  │  TIER B  (research) 🔬       │
                 │  ECFP-2048 fingerprints   │  │  MPNN GNN (atoms/bonds)      │
                 │  LightGBM × 7 ensemble    │  │  + protein embedding (ESM2-  │
                 │  mean = pred, σ = uncert. │  │  ready) + MC-dropout         │
                 └──────────────┬────────────┘  └──────────┬───────────────────┘
                                │                          │
                        ┌───────▼──────────────────────────▼───────┐
                        │      FLASK WEB APP  (3 tabs)            │
                        │  🎯 Target Hub  → train ANY protein      │
                        │  🧪 Screen      → ranked IC50 + confid. │
                        │  🧬 Design      → GA-evolved new mols   │
                        └─────────────────────────────────────────┘
```

---

## 📊 Results (held-out scaffold-split test, never-seen chemistry)

| Target | Split | RMSE ↓ | R² ↑ | Spearman ρ ↑ | n |
|---|---|---|---|---|---|
| **EGFR** | scaffold | **0.89** | **0.50** | **0.71** | 859 |
| **BRAF** | scaffold | 0.88 | 0.54 | 0.75 | 304 |
| **CDK2** | scaffold | 0.79 | 0.46 | 0.66 | 247 |

**Model comparison (EGFR test):** Tier A (LightGBM ×7) vs Tier B (GNN): RMSE 0.89 vs 0.99 · R² 0.50 vs 0.39 · ρ 0.71 vs 0.63. At <10k labels, gradient boosting wins; Tier B + kinase-family transfer learning is the road to a universal model.

**Uncertainty calibration:** |error| by confidence quartile → 0.51 / 0.66 / 0.71 / 0.77 pChEMBL. The flag means something.

**Reality check (no cherry-picking):**

| Drug | Model (normal EGFR) | Clinical reality |
|---|---|---|
| Afatinib | ~4 nM | most potent in class ✓ |
| Erlotinib / Gefitinib | ~9–27 nM | 1st-gen standards ✓ |
| Osimertinib | ~280 nM ("weak") | ✓ correct: engineered for **mutant** EGFR, spares normal cells |
| Vemurafenib → BRAF | ~74 nM | real ≈ 30 nM ✓ |

---

## 🖥️ Quickstart

```bash
git clone https://github.com/<you>/drugdiscovery-studio && cd drugdiscovery-studio
pip install -r requirements.txt

# 1) Build the EGFR model end-to-end (~15 min, downloads public data)
python run_pipeline.py

# 2) Launch the app
python app/server.py           # → http://localhost:8000
```

**Train any other protein** (e.g. BRAF = CHEMBL5145):
```bash
python src/train_target.py --target CHEMBL5145
# or just type "BRAF" in the app's Target Hub — it resolves by gene name.
```

**Score your own molecules from the CLI:**
```bash
python src/inference.py --tier A --smiles candidates.smi --out scored.csv
# output: pred_pChEMBL · pred_IC50_nM · uncertainty · confidence · Lipinski descriptors
```

---

## 🧬 Design mode

The Design tab runs artificial evolution: top-known binders are mutated (atom swaps, fragment growth, pruning), every child is validated by RDKit, and each generation is scored on:

```
fitness = predicted potency  −  0.4 · uncertainty  +  0.5 · QED(drug-likeness)
```

Elitist survival over 20–40 generations returns novel candidates flagged by **novel compound / novel scaffold** vs the training manifolds. Designed molecules are *hypotheses for a chemist + lab*, not finished drugs.

---

## 🔌 App API (Flask)

| Endpoint | Method | Purpose |
|---|---|---|
| `/api/search_targets?q=BRAF` | GET | UniProt→ChEMBL resolution + data availability |
| `/api/train` | POST | auto-train pipeline for a ChEMBL target |
| `/api/train_status?target=` | GET | live progress |
| `/api/models` | GET | trained models + exam metrics |
| `/api/score` | POST | `{smiles, target, uncertainty}` → ranked rows |
| `/api/design` | POST | `{target, n, generations}` → novel candidates |
| `/api/known_ligands?target=` | GET | top-12 most potent *measured* ligands |

---

## 📁 Project structure

```
├── app/                     # Flask server + 3-tab UI (Target Hub / Screen / Design)
├── src/
│   ├── download_chembl.py   # ChEMBL activity downloader (+ kinase-family pool)
│   ├── data_prep.py         # curation: salts, mutants, duplicates, conflicts
│   ├── scaffold_split.py    # Bemis–Murcko honest split
│   ├── features.py          # ECFP fingerprints + disk cache
│   ├── tier_a.py            # LightGBM ensemble (production)
│   ├── tier_b.py            # MPNN-GNN + protein embedding (research)
│   ├── design_ga.py         # de-novo generator (genetic algorithm)
│   ├── train_target.py      # 1-command auto-train for ANY ChEMBL target
│   ├── train_popular.py     # background queue: 20 popular targets
│   └── inference.py         # CLI scoring + throughput benchmarks
├── run_pipeline.py          # end-to-end orchestrator
├── Dockerfile               # one-command deploy (bakes in the EGFR model)
└── artifacts/               # trained models, metrics, test predictions
```

---

## 🗺️ Roadmap — the generative future

- [x] Per-protein auto-training from public data
- [x] Uncertainty-aware screening & GA-based de-novo design
- [ ] **Molecule modification mode** — fixed-core analog generation (lead optimization, matched-molecular-pair rules)
- [ ] **3D structure step** — dock top candidates (AutoDock Vina) into PDB/AlphaFold structures + pose viewer + consensus scoring
- [ ] **Structure-based bootstrapping** — for data-poor proteins: docking pseudo-labels → FEP calibration → active-learning loop with wet-lab feedback
- [ ] **True generative models** — SELFIES / graph-diffusion generators trained on 3M+ ChEMBL compounds, conditioned on a multi-objective property wishlist (potency, selectivity across our model library, solubility, synthesizability)
- [ ] **Universal affinity model** — Tier B + kinase-family pretraining

---

## ⚠️ Limitations & disclaimer

- Predictions rank **binders to a protein** — whether that protein treats a disease is biological judgment the tool deliberately does not make
- Typical error is ~±1 log unit; use for **shortlisting**, then validate in the lab
- Designed molecules are hypotheses: synthesis feasibility and safety need experts and assays
- No toxicity/selectivity/ADME panels (yet) — proxy descriptors only
- For research/education. Not medical advice; not a validated diagnostic or clinical tool.

---

## 📚 Data sources & credits

- **ChEMBL 37** (EMBL-EBI) — bioactivity data · **UniProt** — protein resolution · **RDKit** — cheminformatics · **LightGBM/PyTorch** — models

## 📄 License

MIT — see [LICENSE](LICENSE).

---

<div align="center"><i>Built as an honest prototype: real data, scaffold-split exams, uncertainty that means something — and a roadmap to full generative chemistry.</i></div>
