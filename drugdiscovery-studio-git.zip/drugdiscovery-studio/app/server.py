"""
DrugDiscovery Studio v2 — train/screen/design for ANY ChEMBL protein target.

    python app/server.py        # serves on 0.0.0.0:8000

Tabs:
  1. Target Hub — search any human protein, see data availability, one-click
     auto-train a Tier A affinity model from real public data.
  2. Screen — score your own molecules against any trained target model.
  3. Design — evolve novel molecules optimized for the chosen target.
"""
import json
import os
import pickle
import subprocess
import sys
import threading
import time

import numpy as np
import pandas as pd
import requests
from flask import Flask, jsonify, request, Response
from rdkit import Chem
from rdkit.Chem import Crippen, Descriptors, Lipinski, rdMolDescriptors

ROOT = os.path.join(os.path.dirname(__file__), "..")
sys.path.insert(0, os.path.join(ROOT, "src"))
from features import featurize          # noqa: E402
from tier_a import ensemble_predict     # noqa: E402

app = Flask(__name__)
MODELS = {}          # target_id -> {"models":..., "scale":..., "meta":...}
TRAIN_LOCK = threading.Lock()
MAX_MOLS = 10000
CHEMBL = "https://www.ebi.ac.uk/chembl/api/data"

TARGET_META = {  # static info for the pre-trained demo model
    "CHEMBL203": {"name": "EGFR (Epidermal growth factor receptor erbB1)",
                  "organism": "Homo sapiens", "builtin": True},
}


def target_dirs(tid):
    if tid == "CHEMBL203":
        return {"split": os.path.join(ROOT, "data/processed/egfr_split.csv"),
                "raw": os.path.join(ROOT, "data/raw/egfr_chembl203.csv"),
                "art": os.path.join(ROOT, "artifacts/tier_a")}
    return {"split": os.path.join(ROOT, "data/targets", tid, "split.csv"),
            "raw": os.path.join(ROOT, "data/targets", tid, "raw.csv"),
            "art": os.path.join(ROOT, "artifacts/targets", tid)}


def trained_targets():
    out = {}
    for tid in ["CHEMBL203"]:
        d = target_dirs(tid)
        if os.path.exists(os.path.join(d["art"], "ensemble.pkl")):
            meta = dict(TARGET_META.get(tid, {"name": tid, "organism": "?"}))
            try:
                with open(os.path.join(d["art"], "metrics.json")) as f:
                    m = json.load(f)["test"]
                meta["metrics"] = m
            except Exception:
                pass
            out[tid] = meta
    base = os.path.join(ROOT, "artifacts/targets")
    if os.path.isdir(base):
        for tid in os.listdir(base):
            if os.path.exists(os.path.join(base, tid, "ensemble.pkl")):
                meta = dict(out.get(tid, {"name": tid}))
                try:
                    with open(os.path.join(base, tid, "metrics.json")) as f:
                        meta["metrics"] = json.load(f)["test"]
                    with open(os.path.join(base, tid, "target_info.json")) as f:
                        meta.update(json.load(f))
                except Exception:
                    pass
                out[tid] = meta
    return out


def get_model(tid):
    if tid not in MODELS:
        d = target_dirs(tid)
        pkl = os.path.join(d["art"], "ensemble.pkl")
        if not os.path.exists(pkl):
            return None
        with open(pkl, "rb") as f:
            d2 = pickle.load(f)
        MODELS[tid] = (d2["models"], d2["unc_scale"])
    return MODELS.get(tid)


# ----------------------------------------------------------------- ChEMBL
def _annotate_counts(cands, max_n=6):
    out = []
    seen = set()
    for c in cands:
        if c["chembl_id"] in seen:
            continue
        seen.add(c["chembl_id"])
        try:
            a = requests.get(f"{CHEMBL}/activity.json",
                             params={"target_chembl_id": c["chembl_id"],
                                     "standard_type__in": "Ki,IC50,Kd",
                                     "pchembl_value__gte": 3, "limit": 1},
                             timeout=30).json()
            c["n_activities"] = a["page_meta"]["total_count"]
        except Exception:
            c["n_activities"] = None
        out.append(c)
        if len(out) >= max_n:
            break
    return out


def _human_single(t):
    return t.get("organism") == "Homo sapiens" and t.get("target_type") == "SINGLE PROTEIN"


def search_targets(q, limit=6):
    """Gene-symbol-aware search: UniProt (gene/protein name) -> ChEMBL accession
    lookup, plus ChEMBL pref_name icontains, plus full-text fallback."""
    cands, gene_hits = [], set()
    # 1) UniProt gene-symbol / protein search -> accession -> ChEMBL
    try:
        u = requests.get("https://rest.uniprot.org/uniprotkb/search",
                         params={"query": f"(gene:{q} OR protein_name:{q}) AND organism_id:9606 AND reviewed:true",
                                 "fields": "accession,gene_names,protein_name",
                                 "format": "json", "size": "8"}, timeout=30).json()
        for e in u.get("results", []):
            acc = e["primaryAccession"]
            gene = (e.get("genes") or [{}])[0].get("geneName", {}).get("value", "")
            pname = e["proteinDescription"]["recommendedName"]["fullName"]["value"]
            tr = requests.get(f"{CHEMBL}/target.json",
                              params={"target_components__accession": acc, "limit": 5},
                              timeout=30).json()
            for t in tr.get("targets", []):
                if _human_single(t):
                    if gene.upper() == q.upper():
                        gene_hits.add(t["target_chembl_id"])
                    cands.append({"chembl_id": t["target_chembl_id"], "name": t["pref_name"],
                                  "gene": gene, "uniprot": acc,
                                  "boost": gene.upper() == q.upper()})
    except Exception:
        pass
    # 2) ChEMBL pref_name contains query
    try:
        tr = requests.get(f"{CHEMBL}/target.json",
                          params={"pref_name__icontains": q, "limit": 20}, timeout=30).json()
        for t in tr.get("targets", []):
            if _human_single(t):
                cands.append({"chembl_id": t["target_chembl_id"], "name": t["pref_name"],
                              "gene": "", "uniprot": "", "boost": q.lower() in t["pref_name"].lower()})
    except Exception:
        pass
    # rank: gene-symbol match first, then name match
    ordered = sorted(cands, key=lambda c: -int(c["boost"]))
    out = _annotate_counts(ordered, limit)
    for c in out:
        c.pop("boost", None)
    # 3) fallback: legacy full-text
    if not out:
        try:
            r = requests.get(f"{CHEMBL}/target.json", params={"q": q, "limit": 30}, timeout=30)
            legacy = [{"chembl_id": t["target_chembl_id"], "name": t["pref_name"], "gene": "", "uniprot": ""}
                      for t in r.json().get("targets", []) if _human_single(t)]
            out = _annotate_counts(legacy, limit)
        except Exception:
            pass
    return out


# ----------------------------------------------------------------- helpers
def parse_smiles(text):
    out = []
    for line in (text or "").strip().splitlines():
        line = line.strip()
        if not line or line.lower().startswith("smiles"):
            continue
        parts = line.replace(",", " ").split()
        out.append({"smiles": parts[0], "name": " ".join(parts[1:]) if len(parts) > 1 else ""})
        if len(out) >= MAX_MOLS:
            break
    return out


def descriptors(smiles):
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        return None
    mw, lp = Descriptors.MolWt(mol), Crippen.MolLogP(mol)
    hbd, hba = Lipinski.NumHDonors(mol), Lipinski.NumHAcceptors(mol)
    return {"mw": round(mw, 1), "clogp": round(lp, 2), "hbd": hbd, "hba": hba,
            "tpsa": round(rdMolDescriptors.CalcTPSA(mol), 1),
            "rotb": Lipinski.NumRotatableBonds(mol),
            "rostkoff": int(hbd <= 5 and hba <= 10 and mw <= 500 and lp <= 5)}


def score_with(tid, smiles_list, with_unc=True):
    bundle = get_model(tid)
    if bundle is None:
        return None
    models, scale = bundle
    X, bad = featurize(smiles_list)
    if with_unc:
        mu, sd = ensemble_predict(models, X)
        sd = sd * scale
    else:
        mu = models[0].predict(X)
        sd = np.full_like(mu, np.nan)
    return mu, sd, bad


# ----------------------------------------------------------------- API
@app.route("/api/models")
def api_models():
    return jsonify(trained_targets())


@app.route("/api/search_targets")
def api_search():
    q = request.args.get("q", "").strip()
    if len(q) < 2:
        return jsonify({"error": "query too short"}), 400
    try:
        return jsonify({"results": search_targets(q)})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/train", methods=["POST"])
def api_train():
    payload = request.get_json(force=True)
    tid = payload.get("target", "").upper()
    name = payload.get("name", tid)
    if not tid.startswith("CHEMBL"):
        return jsonify({"error": "invalid target id"}), 400
    d = target_dirs(tid)
    status_p = os.path.join(d["art"], "status.json")
    if os.path.exists(os.path.join(d["art"], "ensemble.pkl")):
        return jsonify({"status": "already_trained"})
    if os.path.exists(status_p):
        try:
            st = json.load(open(status_p))
            if not st.get("done") and time.time() - st.get("ts", 0) < 1800:
                return jsonify({"status": "already_running"})
        except Exception:
            pass
    if not TRAIN_LOCK.acquire(blocking=False):
        return jsonify({"status": "busy", "message": "another target is training; retry later"})
    os.makedirs(d["art"], exist_ok=True)
    with open(os.path.join(d["art"], "target_info.json"), "w") as f:
        json.dump({"name": name, "organism": "Homo sapiens"}, f)

    def worker():
        try:
            subprocess.run([sys.executable, os.path.join(ROOT, "src/train_target.py"),
                            "--target", tid], cwd=ROOT)
        finally:
            TRAIN_LOCK.release()

    threading.Thread(target=worker, daemon=True).start()
    return jsonify({"status": "started"})


@app.route("/api/train_status")
def api_train_status():
    tid = request.args.get("target", "").upper()
    d = target_dirs(tid)
    p = os.path.join(d["art"], "status.json")
    if os.path.exists(os.path.join(d["art"], "ensemble.pkl")):
        return jsonify({"stage": "done", "done": True, "trained": True})
    if os.path.exists(p):
        return jsonify(json.load(open(p)))
    return jsonify({"stage": "not_started", "done": False})


@app.route("/api/score", methods=["POST"])
def api_score():
    payload = request.get_json(force=True)
    tid = payload.get("target", "CHEMBL203").upper()
    entries = parse_smiles(payload.get("smiles", ""))
    if not entries:
        return jsonify({"error": "No SMILES found in input."}), 400
    t0 = time.time()
    res = score_with(tid, [e["smiles"] for e in entries], payload.get("uncertainty", True))
    if res is None:
        return jsonify({"error": f"No trained model for {tid}. Train it first in Target Hub."}), 400
    mu, sd, _ = res
    rows, failed = [], 0
    for e, p, u in zip(entries, mu, sd):
        d = descriptors(e["smiles"])
        if d is None:
            failed += 1
            continue
        ic50 = float(10 ** (9 - p))
        rows.append({"name": e["name"], "smiles": e["smiles"],
                     "pred_pchembl": round(float(p), 3),
                     "pred_ic50_nM": round(ic50, 2) if ic50 < 1e7 else round(ic50),
                     "uncertainty": round(float(u), 3) if not np.isnan(u) else None,
                     "confidence": round(float(1 / (1 + u)), 4) if not np.isnan(u) else None,
                     **d})
    rows.sort(key=lambda r: -r["pred_pchembl"])
    return jsonify({"rows": rows, "failed": failed, "n": len(rows),
                    "elapsed_s": round(time.time() - t0, 2), "target": tid})


@app.route("/api/design", methods=["POST"])
def api_design():
    payload = request.get_json(force=True)
    tid = payload.get("target", "CHEMBL203").upper()
    n = min(int(payload.get("n", 12)), 30)
    gens = min(int(payload.get("generations", 20)), 40)
    d = target_dirs(tid)
    if not os.path.exists(os.path.join(d["art"], "ensemble.pkl")):
        return jsonify({"error": f"No trained model for {tid}."}), 400
    t0 = time.time()
    try:
        sys.path.insert(0, os.path.join(ROOT, "src"))
        from design_ga import design
        rows = design(d["split"], d["art"], n=n, generations=gens)
        for r in rows:
            det = descriptors(r["smiles"]) or {}
            r.update(det)
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    return jsonify({"rows": rows, "n": len(rows),
                    "elapsed_s": round(time.time() - t0, 1), "target": tid})


@app.route("/api/known_ligands")
def api_known():
    tid = request.args.get("target", "CHEMBL203").upper()
    n = min(int(request.args.get("n", 12)), 30)
    d = target_dirs(tid)
    if not os.path.exists(d["raw"]):
        return jsonify({"error": "raw data not available for this target"}), 400
    df = pd.read_csv(d["raw"], usecols=["molecule_chembl_id", "canonical_smiles",
                                        "pchembl_value", "standard_relation"])
    df = df[df["standard_relation"].fillna("=").isin(["=", "'='"])]
    g = (df.dropna(subset=["pchembl_value"])
           .groupby("molecule_chembl_id")
           .agg(smi=("canonical_smiles", "first"), p=("pchembl_value", "max"))
           .sort_values("p", ascending=False).drop_duplicates("smi").head(n).reset_index())
    names = {}
    try:
        ids = ",".join(g["molecule_chembl_id"].tolist())
        mres = requests.get(f"{CHEMBL}/molecule.json",
                            params={"molecule_chembl_id__in": ids, "limit": n}, timeout=30).json()
        names = {m["molecule_chembl_id"]: (m.get("pref_name") or "")
                 for m in mres.get("molecules", [])}
    except Exception:
        pass
    rows = []
    for _, r in g.iterrows():
        p = float(r["p"])
        rows.append({"chembl_id": r["molecule_chembl_id"], "smiles": r["smi"],
                     "name": str(names.get(r["molecule_chembl_id"], "")).title(),
                     "measured_pchembl": round(p, 2),
                     "measured_ic50_nM": round(10 ** (9 - p), 2) if 9 - p < 7 else round(10 ** (9 - p))})
    return jsonify({"rows": rows, "target": tid})


@app.route("/api/health")
def health():
    return jsonify({"ok": True})


# ----------------------------------------------------------------- UI
PAGE = open(os.path.join(os.path.dirname(__file__), "page.html")).read()


@app.route("/")
def index():
    return Response(PAGE, mimetype="text/html")


if __name__ == "__main__":
    print("DrugDiscovery Studio v2 on 0.0.0.0:8000")
    app.run(host="0.0.0.0", port=8000, threaded=True)
