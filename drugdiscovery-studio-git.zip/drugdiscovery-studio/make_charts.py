"""Generate result charts from the trained models for the presentation."""
import json

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

plt.rcParams.update({
    "font.family": "DejaVu Sans", "font.size": 12,
    "axes.edgecolor": "#3a4a5c", "axes.labelcolor": "#21303f",
    "xtick.color": "#4a5b6d", "ytick.color": "#4a5b6d",
    "figure.facecolor": "white", "axes.facecolor": "#f7fafd",
})
ACC, ACC2, MUT = "#0e7ab0", "#f4a742", "#8ea3b5"

A = pd.read_csv("artifacts/tier_a/test_predictions.csv")
B = pd.read_csv("artifacts/tier_b/test_predictions.csv")
ma = json.load(open("artifacts/tier_a/metrics.json"))
mb = json.load(open("artifacts/tier_b/metrics.json"))

# ---- 1. Predicted vs true scatter (Tier A), colored by uncertainty ----
fig, ax = plt.subplots(figsize=(6.4, 5))
sc = ax.scatter(A["y_true"], A["y_pred"], c=A["uncertainty"], cmap="RdYlGn_r",
                s=14, alpha=0.75, edgecolors="none")
lims = [3.5, 11.5]
ax.plot(lims, lims, "--", color=MUT, lw=1.2, label="perfect prediction")
ax.plot(lims, [l - 1 for l in lims], ":", color=MUT, lw=1)
ax.plot(lims, [l + 1 for l in lims], ":", color=MUT, lw=1, label="±1 log window")
ax.set_xlim(lims); ax.set_ylim(lims)
ax.set_xlabel("True potency (pChEMBL, scaffold-held-out test set)")
ax.set_ylabel("Predicted potency")
ax.set_title(f"Tier A on never-seen chemistry: R²={ma['test']['r2']:.2f}, "
             f"ρ={ma['test']['spearman']:.2f}", fontsize=12)
cb = fig.colorbar(sc, ax=ax); cb.set_label("model uncertainty")
ax.legend(frameon=False, loc="lower right", fontsize=10)
fig.tight_layout(); fig.savefig("artifacts/chart_scatter.png", dpi=160); plt.close(fig)

# ---- 2. Tier A vs Tier B metric bars ----
metrics = [("RMSE ↓", "rmse"), ("MAE ↓", "mae"), ("R² ↑", "r2"), ("Spearman ρ ↑", "spearman")]
x = np.arange(len(metrics)); w = 0.36
va = [ma["test"][k] for _, k in metrics]
vb = [mb["test"][k] for _, k in metrics]
fig, ax = plt.subplots(figsize=(7.2, 4.2))
ax.bar(x - w/2, va, w, label="Tier A — ECFP + LightGBM ×7 (production)", color=ACC)
ax.bar(x + w/2, vb, w, label="Tier B — GNN + protein embedding", color=ACC2)
for xi, (a, b) in zip(x, zip(va, vb)):
    ax.text(xi - w/2, a + 0.03, f"{a:.2f}", ha="center", fontsize=10, fontweight="bold")
    ax.text(xi + w/2, b + 0.03, f"{b:.2f}", ha="center", fontsize=10)
ax.set_xticks(x); ax.set_xticklabels([m for m, _ in metrics])
ax.set_ylim(0, 1.15); ax.legend(frameon=False, fontsize=10)
ax.set_title("Scaffold-split test comparison — Tier A wins at this data scale", fontsize=12)
fig.tight_layout(); fig.savefig("artifacts/chart_metrics.png", dpi=160); plt.close(fig)

# ---- 3. Cleaning funnel ----
rep = json.load(open("data/processed/cleaning_report.json"))
stages = ["Raw ChEMBL\nrows", "After QC\nfilters", "After mutant-assay\nremoval", "After structure\nstandardization",
          "Unique clean\ncompounds"]
vals = [rep["n_raw_rows"],
        rep["n_raw_rows"] - rep["drop_potential_duplicates"],
        rep["after_assay_filters"],
        rep["after_assay_filters"] - rep["drop_unparseable_smiles"],
        rep["n_unique_compounds"]]
fig, ax = plt.subplots(figsize=(7.6, 4.2))
bars = ax.barh(stages[::-1], vals[::-1], color=[ACC, "#1c8cc4", "#2fa3d8", "#4ab5e8", "#7ccbf5"][::-1])
for b, v in zip(bars, vals[::-1]):
    ax.text(v + 150, b.get_y() + b.get_height()/2, f"{v:,}", va="center", fontsize=10, fontweight="bold")
ax.set_xlim(0, max(vals) * 1.18)
ax.set_title("EGFR data curation funnel — 20,949 raw → 8,604 trusted labels", fontsize=12)
ax.set_xlabel("records kept")
fig.tight_layout(); fig.savefig("artifacts/chart_funnel.png", dpi=160); plt.close(fig)

# ---- 4. Uncertainty calibration ----
q = pd.qcut(A["uncertainty"], 4, labels=["Q1 most\nconfident", "Q2", "Q3", "Q4 least\nconfident"])
errs = (A["y_true"] - A["y_pred"]).abs()
grp = errs.groupby(q, observed=True).mean()
fig, ax = plt.subplots(figsize=(6.2, 4.2))
colors = ["#1e8e5a", "#9fc06a", "#e8b04b", "#c0392b"]
ax.bar(grp.index, grp.values, color=colors)
for i, v in enumerate(grp.values):
    ax.text(i, v + 0.012, f"{v:.2f}", ha="center", fontweight="bold", fontsize=11)
ax.set_ylabel("mean absolute error (pChEMBL)")
ax.set_title("Confidence signal works: low-confidence = bigger errors", fontsize=12)
fig.tight_layout(); fig.savefig("artifacts/chart_uncertainty.png", dpi=160); plt.close(fig)

print("charts saved:", *[f"artifacts/chart_{n}.png" for n in
      ("scatter","metrics","funnel","uncertainty")], sep="\n  ")
