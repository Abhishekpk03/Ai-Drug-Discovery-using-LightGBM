"""Complete presentation: topic + prototype + future vision."""
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor

ACC = RGBColor(0x0E, 0x7A, 0xB0)
DARK = RGBColor(0x0F, 0x1A, 0x28)
MUT = RGBColor(0x5A, 0x6B, 0x7C)
LIGHT = RGBColor(0xEE, 0xF4, 0xF9)
WHITE = RGBColor(0xFF, 0xFF, 0xFF)
GOLD = RGBColor(0xF4, 0xA7, 0x42)

prs = Presentation()
prs.slide_width = Inches(13.333)
prs.slide_height = Inches(7.5)
BLANK = prs.slide_layouts[6


] if False else prs.slide_layouts[6]


def slide(title, subtitle=None):
    s = prs.slides.add_slide(BLANK)
    tb = s.shapes.add_textbox(Inches(0.6), Inches(0.32), Inches(12.2), Inches(1.05))
    p = tb.text_frame.paragraphs[0]
    r = p.add_run(); r.text = title
    r.font.size = Pt(30); r.font.bold = True; r.font.color.rgb = DARK
    if subtitle:
        p2 = tb.text_frame.add_paragraph()
        r2 = p2.add_run(); r2.text = subtitle
        r2.font.size = Pt(14.5); r2.font.color.rgb = MUT
    bar = s.shapes.add_shape(1, Inches(0.6), Inches(1.26), Inches(1.6), Pt(4))
    bar.fill.solid(); bar.fill.fore_color.rgb = ACC; bar.line.fill.background()
    return s


def bullets(s, items, top=1.55, size=16.5, left=0.7, width=12.0, gap=7):
    tb = s.shapes.add_textbox(Inches(left), Inches(top), Inches(width), Inches(5.7))
    tf = tb.text_frame; tf.word_wrap = True
    first = True
    for head, sub in items:
        p = tf.paragraphs[0] if first else tf.add_paragraph()
        first = False
        p.space_after = Pt(gap)
        r = p.add_run(); r.text = "▸ " + head
        r.font.size = Pt(size); r.font.bold = True; r.font.color.rgb = DARK
        if sub:
            r2 = p.add_run(); r2.text = " — " + sub
            r2.font.size = Pt(size - 1.5); r2.font.bold = False; r2.font.color.rgb = MUT
    return tb


def notes(s, text):
    s.notes_slide.notes_text_frame.text = text


def table(s, data, left=0.7, top=1.6, width=11.9, height=3.5, size=13, col_widths=None):
    rows, cols = len(data), len(data[0])
    tbl = s.shapes.add_table(rows, cols, Inches(left), Inches(top), Inches(width), Inches(height)).table
    if col_widths:
        for i, w in enumerate(col_widths):
            tbl.columns[i].width = Inches(w)
    for i, row in enumerate(data):
        for j, val in enumerate(row):
            c = tbl.cell(i, j); c.text = str(val)
            par = c.text_frame.paragraphs[0]
            par.font.size = Pt(size)
            par.font.color.rgb = WHITE if i == 0 else DARK
            par.font.bold = (i == 0 or j == 0)
            c.fill.solid()
            c.fill.fore_color.rgb = ACC if i == 0 else (LIGHT if i % 2 else WHITE)
    return tbl


def divider(title, sub, icon=""):
    s = prs.slides.add_slide(BLANK)
    bg = s.shapes.add_shape(1, 0, 0, prs.slide_width, prs.slide_height)
    bg.fill.solid(); bg.fill.fore_color.rgb = DARK; bg.line.fill.background()
    tb = s.shapes.add_textbox(Inches(1), Inches(2.7), Inches(11.3), Inches(2.2))
    p = tb.text_frame.paragraphs[0]
    r = p.add_run(); r.text = title
    r.font.size = Pt(46); r.font.bold = True; r.font.color.rgb = WHITE
    p2 = tb.text_frame.add_paragraph(); p2.space_before = Pt(14)
    r = p2.add_run(); r.text = sub
    r.font.size = Pt(18); r.font.color.rgb = GOLD
    notes(s, "SECTION TRANSITION: pause two seconds, then: " + sub)
    return s


def picture(s, path, left, top, width=None, height=None):
    kw = {}
    if width: kw["width"] = Inches(width)
    if height: kw["height"] = Inches(height)
    s.shapes.add_picture(path, Inches(left), Inches(top), **kw)


# ================================ 1 TITLE ================================
s = prs.slides.add_slide(BLANK)
bg = s.shapes.add_shape(1, 0, 0, prs.slide_width, prs.slide_height)
bg.fill.solid(); bg.fill.fore_color.rgb = DARK; bg.line.fill.background()
tb = s.shapes.add_textbox(Inches(1), Inches(1.9), Inches(11.3), Inches(4.2))
p = tb.text_frame.paragraphs[0]
r = p.add_run(); r.text = "AI-Driven Drug Discovery"
r.font.size = Pt(56); r.font.bold = True; r.font.color.rgb = WHITE
p2 = tb.text_frame.add_paragraph(); p2.space_before = Pt(6)
r = p2.add_run(); r.text = "From predicting protein binders to designing tomorrow's molecules"
r.font.size = Pt(24); r.font.color.rgb = RGBColor(0x9D, 0xC7, 0xF5)
p3 = tb.text_frame.add_paragraph(); p3.space_before = Pt(30)
r = p3.add_run(); r.text = ("A working prototype (DrugDiscovery Studio: predict · screen · design), real results on "
                            "public data, and the roadmap to fully generative, structure-aware drug design")
r.font.size = Pt(15); r.font.color.rgb = RGBColor(0x8E, 0xA3, 0xB5)
notes(s, "Open with the hook: bringing a drug to market costs ~$1–2B and ~10 years, and most of that is spent testing molecules that fail. This talk: how AI changes that math — with a real working system, not slideware. Then the roadmap to where this is going: machines that design molecules with exactly the properties you ask for.")

# ================================ 2 AGENDA ================================
s = slide("Talk roadmap", "three acts")
bullets(s, [
    ("ACT I — The problem & the field", "why drug discovery is slow, and the 3 computational toolkits (physics, ML, generative AI)"),
    ("ACT II — Our prototype: DrugDiscovery Studio", "a working system: trained on real data, honest accuracy, a 3-tab web app, 20+ protein models; live demo"),
    ("ACT III — Future vision", "generate molecules by required properties · modify molecules on demand · 3D-structure-aware design · self-generated training data"),
], size=19, gap=20)
notes(s, "Set expectations: Act I is 4 minutes of shared vocabulary, Act II shows the working thing, Act III is the vision. Invite questions on accuracy claims at the end — we welcome them.")

# ================================ ACT I ================================
divider("ACT I", "The problem, and the three computational toolkits")

s = slide("Why drug discovery is slow and expensive")
bullets(s, [
    ("~10 years and ~$1–2B per approved drug", "most of it spent testing candidates that fail"),
    ("The search space is larger than astronomy", "~10⁶⁰ possible drug-like molecules — brute force is impossible"),
    ("The lab bottleneck", "each binding experiment costs days & money; you can only test ~10⁴ molecules per campaign"),
    ("The opportunity", "if a computer can predict binding even roughly, we test 50 smart candidates instead of 50,000 random ones"),
], size=17, gap=14)
notes(s, "Cost framing matters to any audience: each avoided failed experiment is money and months saved. AI doesn't replace experiments; it spends them better.")

s = slide("Four words you need for everything that follows")
table(s, [
    ["Term", "Plain meaning"],
    ["Protein target", "The biological machine a drug must switch off (EGFR→lung cancer, BRAF→melanoma)"],
    ["Molecule / ligand", "The candidate drug — the 'key' for the protein's 'lock'"],
    ["SMILES", "Any molecule written as one line of text (aspirin = CC(=O)Oc1ccccc1C(=O)O)"],
    ["Binding affinity / IC50", "How tightly the key fits: lower nM = stronger; pChEMBL = log-scale version"],
], size=14, height=3.4, col_widths=[3.4, 8.5])
notes(s, "Anchor the audience in 60 seconds. Everything later is compounds of these four ideas.")

s = slide("Three computational toolkits — alphabet for this talk")
table(s, [
    ["Toolkit", "Idea", "Needs", "Strength", "Weakness"],
    ["Physics: docking & FEP", "Simulate the key physically fitting the 3D lock", "3D structure only", "No data needed; explains HOW it binds", "Slow; scores are noisy"],
    ["ML / QSAR (our core)", "Learn potency patterns from past experiments", "Thousands of labels", "Very fast; accurate on known targets", "No help on day 1 of a new target"],
    ["Generative AI", "Learn the 'grammar' of chemistry and write NEW molecules", "Molecule corpora + objectives", "Invents novel, property-tuned compounds", "Needs validation; synthesizability"],
], size=12.5, height=3.8, col_widths=[2.7, 3.4, 2.1, 2.8, 2.6])
notes(s, "This taxonomy keeps the whole field in one slide. Key insight: the toolkits are complementary, and the future (Act III) is about chaining them: generate → predict → dock → verify in a loop.")

# ================================ ACT II ================================
divider("ACT II", "Our prototype — DrugDiscovery Studio (real, trained, running)")

s = slide("System architecture — from public data to live app")
bullets(s, [
    ("1 · Ingest", "ChEMBL API (world's largest public binding database) + UniProt — any human protein"),
    ("2 · Curate", "salts stripped, duplicates merged, mutant assays removed, conflicting measurements dropped"),
    ("3 · Featurize", "molecules → 2,048-bit ECFP fingerprints (cached for millisecond rescoring)"),
    ("4 · Train", "Tier A: ensemble of LightGBM models · Tier B: graph neural net + protein embedding"),
    ("5 · Score honestly", "Bemis–Murcko scaffold split — the exam contains ONLY unseen chemistry"),
    ("6 · Serve", "Flask web app: search/train any protein, screen libraries, design new molecules"),
], size=16, gap=10)
notes(s, "One breath per box. Everything is reproducible: run_pipeline.py does steps 1–5 with one command.")

s = slide("Data curation — garbage in, garbage out (EGFR example)")
picture(s, "artifacts/chart_funnel.png", 0.8, 1.6, width=7.4)
bullets(s, [
    ("20,949 raw rows → 8,604 trusted compounds", ""),
    ("Removed 6,236 mutant-EGFR assay rows", "structured field + curated keywords"),
    ("Dropped 2,316 potentially duplicated publications", ""),
    ("Dropped 652 compounds with contradictory measurements", ">1 log spread"),
], left=8.4, width=4.6, top=1.9, size=13.5, gap=10)
notes(s, "Curation is where most amateur pipelines fail. The mutant-removal step paid off later — it is what let the model correctly call osimertinib weak on normal EGFR.")

s = slide("Two model tiers — chosen by data, not fashion")
bullets(s, [
    ("Tier A (production)", "ECFP fingerprints → 7-model LightGBM ensemble; mean = prediction, disagreement = uncertainty"),
    ("Tier B (research)", "graph neural network (atoms=nodes, bonds=edges) conditioned on a protein-sequence embedding; MC-dropout uncertainty"),
    ("Head-to-head result", "Tier A wins today (R² 0.50 vs 0.39) — GNNs need 10–100× more data"),
    ("Why keep Tier B?", "its protein embedding makes ONE model serve MANY proteins — the path to a universal affinity model via kinase-family transfer learning"),
], size=16, gap=12)
notes(s, "If asked 'why not deep learning?': we built both and measured. Deep learning is the future path, gradient boosting is the present optimum at this scale of data.")

s = slide("The honest exam — scaffold split")
bullets(s, [
    ("The trap", "testing on molecules similar to training = inflated, fake accuracy"),
    ("Our rule", "all molecules sharing a core skeleton go to EITHER train or test — never both"),
    ("The exam", "859 test molecules with 859 unique, never-before-seen scaffolds"),
    ("Result", "conservative numbers you can trust in the field — this is the standard reviewers expect"),
], size=17, gap=14)
notes(s, "Emphasize: our reported metrics are the LOWER bound (hard exam), unlike typical papers that quote random splits.")

s = slide("Results on completely unseen chemistry")
picture(s, "artifacts/chart_scatter.png", 0.7, 1.55, height=5.4)
picture(s, "artifacts/chart_metrics.png", 6.9, 1.7, width=6.0)
notes(s, "Left: predicted vs true on the scaffold-held-out test set, colored by uncertainty — red (uncertain) points visibly scatter more, exactly what a good uncertainty signal should do. Right: metric-by-metric, Tier A beats Tier B. Ranking correlation 0.71 means the top-50 shortlist is genuinely enriched.")

s = slide("Confidence you can act on")
picture(s, "artifacts/chart_uncertainty.png", 0.8, 1.6, width=6.2)
bullets(s, [
    ("Most confident quartile: MAE ≈ 0.51", "vs least confident ≈ 0.77"),
    ("Same potency ≠ same trust", "green/amber/red pills tell users when to believe a number"),
    ("This turns 'a model' into 'a decision tool'", ""),
], left=7.4, width=5.4, top=2.0, size=15, gap=12)
notes(s, "Uncertainty is the differentiator between research and decision support. In pharma, knowing when NOT to trust the model saves more money than raw accuracy.")

s = slide("Reality check — the AI reproduces clinical pharmacology")
table(s, [
    ["Drug (not cherry-picked)", "Model says (WT EGFR)", "Clinical reality"],
    ["Afatinib", "~4 nM — excellent", "Irreversible, most potent in class ✓"],
    ["Dacomitinib", "~8 nM", "2nd-gen covalent EGFRi ✓"],
    ["Erlotinib / Gefitinib", "~9–27 nM", "1st-gen standards ✓"],
    ["Osimertinib", "~280 nM — 'weak' ⚠", "CORRECT: designed to target MUTANT EGFR and spare normal cells ✓"],
], size=13, height=3.6, col_widths=[3.2, 4.1, 4.6])
notes(s, "The osimertinib row is the showstopper: the model was trained only on wild-type data and correctly calls the mutant-selective drug weak here. It learned drug selectivity logic straight from curated data.")

s = slide("The app — three tabs a scientist actually uses")
table(s, [
    ["Tab", "What you do", "What happens"],
    ["1 · Target Hub", "Type any protein (BRAF, JAK2, DRD2…)", "UniProt→ChEMBL resolution, data-availability report, 4-min auto-train, per-protein exam scores"],
    ["2 · Screen", "Paste/upload up to 10k SMILES", "Ranked potency (IC50 nM) + confidence pills + Lipinski profile + CSV export; or fetch the protein's top-12 known binders"],
    ["3 · Design", "Pick protein + count", "Genetic algorithm evolves NEW molecules: potency × drug-likeness × confidence; novelty flags per candidate"],
], size=13.5, height=3.3, col_widths=[2.4, 3.9, 5.6])
notes(s, "Demo script (90 seconds): load the 5-drug example → score (instant). Then Design tab → 12 candidates in ~60s → 'these molecules do not exist; the AI just proposed them.' Finish with Target Hub: type an audience-suggested protein.")

s = slide("One engine, many proteins")
bullets(s, [
    ("Models today", "EGFR, BRAF, CDK2, CDK9 + background queue: JAK2, ALK, MET, PARP1, HDAC1, DRD2, ADRB2, HTR2A, HSP90, PIK3CA, mTOR, AKT1, HER2, ABL1, VEGFR2, SRC, ACE, AR"),
    ("Each keeps its report card", "RMSE 0.79–0.89, Spearman 0.65–0.75 across trained targets"),
    ("Repurposers' dream", "disease-centric? no — protein-centric: the day a new disease maps to a trained protein, screening starts the same afternoon"),
    ("Honest gate", "protein with <300 public compounds → the app refuses rather than fabricate a model"),
], size=16, gap=12)
notes(s, "Mention validated examples: vemurafenib predicted 74 nM vs ~30 nM real for BRAF. The protein-centric design is what makes disease number N free after disease number 1.")

s = slide("Speed & scale — built for libraries, not demos")
table(s, [
    ["Operation", "Throughput", "Practical meaning"],
    ["Fingerprint 1k molecules", "~0.2 s", "featurization is free"],
    ["Score 1k (with uncertainty)", "~0.34 s", "100k compounds in ~30 s"],
    ["Score 1k (single model)", "~0.03 s", "1 million pre-screen in ~30 s"],
    ["Design 15 novel candidates", "~60–90 s", "a chemist's week of sketching, instant"],
], size=13.5, height=3.2, col_widths=[3.6, 2.8, 5.5])
notes(s, "Workflow guidance: point-predict millions, then re-run the top slice with full uncertainty, then send top-100 to docking (Act III).")

# ================================ ACT III ================================
divider("ACT III", "The future vision — from predicting to creating")

s = slide("Vision 1 — Complete molecule generation from a property wishlist", "'I need: potent vs BRAF · selective over EGFR · soluble · oral · patentable'")
bullets(s, [
    ("Today", "our GA optimizes 3 objectives (potency, QED, confidence) around known scaffolds"),
    ("Next", "multi-objective generative models (reinforcement learning / diffusion on graphs) that take an explicit PROPERTY VECTOR scorecard: potency, selectivity vs off-targets, solubility, half-life proxies, synthetic accessibility"),
    ("How it learns selectivity", "score candidates against MANY target models simultaneously (our 20+ model library) — 'hit BRAF, avoid EGFR' becomes a math constraint"),
    ("Output", "not 1 molecule but a Pareto front: trade-offs visualized so chemists pick potency-vs-safety consciously"),
], size=15.5, gap=11)
notes(s, "Frame as: from 'generate strong binders' to 'generate compounds satisfying a clinical product profile'. The multi-model selectivity scoring is already possible with the current app models — it's a scoring change, not a research leap.")

s = slide("Vision 2 — Molecule modification on demand (lead optimization)")
bullets(s, [
    ("The real daily need", "not 'invent from nothing' but 'fix THIS molecule': keep the core, change one handle"),
    ("Operations the system will offer", "grow / shrink / replace an R-group · cyclize a flexible chain · swap ring atoms · block a metabolic hotspot"),
    ("How", "matched-molecular-pair rules learned from millions of past edits + the property models as validators — 'make analogs of X that keep potency but raise solubility'"),
    ("Workflow", "chemist marks the fragment to change → engine proposes ranked analogs with predicted Δpotency/Δsolubility/Δclarity, already constraint-checked"),
], size=15.5, gap=11)
notes(s, "This is how 80% of real medicinal chemistry is done — series optimization. A GA mode with a fixed-core constraint gets us most of the way; MMP transforms make the edits realistic.")

s = slide("Vision 3 — 3D-structure-aware everything")
bullets(s, [
    ("Structures are now free at scale", "PDB crystals (e.g. EGFR 1M17) + AlphaFold for essentially every human protein"),
    ("Near-term in this repo", "dock the app's top-100 candidates (AutoDock Vina) → poses + consensus re-scoring; visual 3D viewer of how the molecule sits in the pocket"),
    (" deeper model", "3D equivariant neural nets (E(n)-GNN, diffusion-based binders) learn from geometry directly — pocket-shape aware, no data-hungry memorization"),
    ("Payoff", "catch false positives the 2D models miss, and explain binding atom-by-atom — the interpretation layer scientists trust"),
], size=15.5, gap=11)
notes(s, "Docking already happens AFTER screening in the pro workflow; bringing it INTO the app closes the loop. Explain 1M17 quickly: it's the EGFR crystal with erlotinib inside — a perfect teaching case.")

s = slide("Vision 4 — Self-generated training data (no-data proteins)")
table(s, [
    ["Data tier", "Source", "Accuracy", "Cost", "Role"],
    ["Pseudo-labels", "Docking thousands of molecules into the pocket", "±2–3 log units", "seconds/mol (CPU)", "bootstrap ranking model"],
    ["Physical labels", "Free-energy (FEP) on the top hundreds", "near-experimental (~1 log)", "hours/mol (GPU)", "calibrate & correct the bootstrap"],
    ["Real labels", "Wet-lab measurements (few dozen, wisely chosen)", "ground truth", "high", "anchor everything"],
], size=13, height=3.3, col_widths=[2.1, 3.7, 2.6, 2.1, 2.4])
notes(s, "The loop is the point: bootstrap with docking → screen billions → validate top with FEP → buy a few real experiments on maximally informative candidates → retrain. Each cycle the model converts from 'guessing physics' to 'knowing the protein'. This is ACTIVE LEARNING — the industry playbook for a brand-new target.")

s = slide("The roadmap — from this repo, in order of cost")
bullets(s, [
    ("1 · Retrofitting (days)", "fixed-core GA = molecule modification mode; multi-target selectivity scoring in Design"),
    ("2 · Structure step (weeks)", "Vina docking + 3D pose viewer for top candidates; docking-pseudo-label bootstrap for data-poor proteins"),
    ("3 · Generative upgrade", "SMILES/SELFIES RL or graph-diffusion generator trained on 3M ChEMBL compounds, conditioned on our models"),
    ("4 · Active-learning loop", "FEP labels + wet-lab feedback → continuous retraining; each lab experiment shrinks future error"),
    ("5 · The endgame", "a conversational co-pilot: protein + property wishlist in → ranked, novel, synthesizable, 3D-validated candidates out"),
], size=15.5, gap=11)
notes(s, "Deliberately ordered by BUILD COST, not by glamour — items 1–2 are already possible inside the current codebase.")

s = slide("Limitations & responsibility")
bullets(s, [
    ("It ranks binders — biology decides whether binding = medicine", ""),
    ("±1 log-unit error is real", "shortlists, not verdicts; novel designs need synthesis + assay"),
    ("Off-target toxicity & ADME are only proxy-scored today", "real panels needed in Act III"),
    ("Dual-use awareness", "generative chemistry must stay guided toward medicines — governance matters as capability grows"),
], size=16, gap=14)
notes(s, "Own the limits before the audience finds them — it converts skeptics into collaborators. The governance note: generative molecular design has dual-use implications; we build for therapeutics.")

s = prs.slides.add_slide(BLANK)
bg = s.shapes.add_shape(1, 0, 0, prs.slide_width, prs.slide_height)
bg.fill.solid(); bg.fill.fore_color.rgb = DARK; bg.line.fill.background()
tb = s.shapes.add_textbox(Inches(1), Inches(2.2), Inches(11.3), Inches(3.2))
p = tb.text_frame.paragraphs[0]
r = p.add_run(); r.text = "Thank you — questions?"
r.font.size = Pt(46); r.font.bold = True; r.font.color.rgb = WHITE
for line in ["Working prototype deployed · models trained on public data (ChEMBL/UniProt) · Dockerfile included",
             "Demo: 5-drug screen in 1 s · design 15 novel candidates in 60 s · any protein auto-trained in ~4 min"]:
    p2 = tb.text_frame.add_paragraph(); p2.space_before = Pt(12)
    r = p2.add_run(); r.text = line
    r.font.size = Pt(16); r.font.color.rgb = RGBColor(0x8E, 0xA3, 0xB5)
notes(s, "Likely Q&A: 1) Like AlphaFold? — complementary: structure prediction vs affinity ranking; future merges them. 2) Accuracy? — Spearman 0.71–0.75 on unseen chemistry; ranking is the product. 3) Could it make a COVID drug on day 1? — no (no data, no vaccine capability); docking + transfer learning would've helped from week ~6, fully by late-2020 when Mpro data accumulated. 4) Our private data? — drop-in CSVs; retrain <1 min. 5) Is generative output synthesizable? — the QED + synthesizability objectives + chemist review; validation is mandatory.")

prs.save("DrugDiscovery_Complete_Presentation.pptx")
print("slides:", len(prs.slides._sldIdLst))
