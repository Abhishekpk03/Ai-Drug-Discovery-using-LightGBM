"""Canva-style redesigned presentation: dark theme, stat cards, icon bullets."""
from pptx import Presentation
from pptx.util import Inches, Pt, Emu
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR

# ---------------- design tokens ----------------
BG = RGBColor(0x0B, 0x12, 0x20)
CARD = RGBColor(0x14, 0x22, 0x3A)
CARD2 = RGBColor(0x17, 0x2A, 0x47)
LINE = RGBColor(0x24, 0x38, 0x55)
TXT = RGBColor(0xEA, 0xF1, 0xF8)
SUB = RGBColor(0x92, 0xA8, 0xBC)
SKY = RGBColor(0x38, 0xBD, 0xF8)
AMBER = RGBColor(0xF5, 0x9E, 0x0B)
GREEN = RGBColor(0x34, 0xD3, 0x99)
RED = RGBColor(0xF8, 0x71, 0x71)
VIOLET = RGBColor(0xA7, 0x8B, 0xFA)

prs = Presentation()
prs.slide_width = Inches(13.333)
prs.slide_height = Inches(7.5)
BLANK = prs.slide_layouts[6]
SW, SH = 13.333, 7.5


def add_bg(s, color=BG):
    sh = s.shapes.add_shape(MSO_SHAPE.RECTANGLE, 0, 0, prs.slide_width, prs.slide_height)
    sh.fill.solid(); sh.fill.fore_color.rgb = color; sh.line.fill.background()
    return sh


def card(s, x, y, w, h, fill=CARD, line=LINE, radius=0.06):
    c = s.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(x), Inches(y), Inches(w), Inches(h))
    c.adjustments[0] = radius
    c.fill.solid(); c.fill.fore_color.rgb = fill
    c.line.color.rgb = line; c.line.width = Pt(1)
    c.shadow.inherit = False
    return c


def txt(s, x, y, w, h, runs, align=PP_ALIGN.LEFT, anchor=MSO_ANCHOR.TOP, sp_after=4):
    """runs: list of paragraphs; each = list of (text, size, bold, color) runs."""
    tb = s.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
    tf = tb.text_frame; tf.word_wrap = True; tf.vertical_anchor = anchor
    first = True
    for para in runs:
        p = tf.paragraphs[0] if first else tf.add_paragraph()
        first = False
        p.alignment = align; p.space_after = Pt(sp_after)
        for (t, size, bold, color) in para:
            r = p.add_run(); r.text = t
            r.font.size = Pt(size); r.font.bold = bold; r.font.color.rgb = color
    return tb


def pill(s, x, y, text, color=SKY, w=1.5):
    p = card(s, x, y, w, 0.34, fill=CARD2, line=color, radius=0.5)
    tf = p.text_frame; tf.margin_left = tf.margin_right = Inches(0.05)
    tf.margin_top = tf.margin_bottom = Pt(0)
    pa = tf.paragraphs[0]; pa.alignment = PP_ALIGN.CENTER
    r = pa.add_run(); r.text = text
    r.font.size = Pt(11); r.font.bold = True; r.font.color.rgb = color
    return p


def header(s, section, title, color=SKY):
    pill(s, 0.65, 0.42, section, color, w=max(1.4, 0.13 * len(section)))
    txt(s, 0.65, 0.82, 12.0, 0.8, [[(title, 30, True, TXT)]])
    ln = s.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(0.65), Inches(1.55), Inches(1.6), Pt(3))
    ln.fill.solid(); ln.fill.fore_color.rgb = color; ln.line.fill.background()


def footer(s, n):
    txt(s, 0.65, 7.08, 8, 0.3, [[("DrugDiscovery Studio — AI for molecular decisions", 10, False, SUB)]])
    txt(s, 12.0, 7.08, 0.7, 0.3, [[(str(n), 10, True, SUB)]], align=PP_ALIGN.RIGHT)


def stat_card(s, x, y, w, h, big, label, color=SKY, icon=""):
    card(s, x, y, w, h, fill=CARD, line=color)
    rows = []
    if icon:
        rows.append([(icon + "  ", 17, True, color)])
    rows.append([(big, 27, True, color)])
    rows.append([(label, 12.5, False, SUB)])
    txt(s, x + 0.22, y + 0.16, w - 0.4, h - 0.3, rows, sp_after=1)


def ibullets(s, items, x=0.65, y=1.9, w=12.05, size=15, gap=10, color=SKY):
    tb = s.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(5.0))
    tf = tb.text_frame; tf.word_wrap = True
    first = True
    for icon, head, sub in items:
        p = tf.paragraphs[0] if first else tf.add_paragraph()
        first = False
        p.space_after = Pt(gap)
        r = p.add_run(); r.text = f"{icon}  "
        r.font.size = Pt(size); r.font.bold = True; r.font.color.rgb = color
        r2 = p.add_run(); r2.text = head
        r2.font.size = Pt(size); r2.font.bold = True; r2.font.color.rgb = TXT
        if sub:
            r3 = p.add_run(); r3.text = "  " + sub
            r3.font.size = Pt(size - 2); r3.font.bold = False; r3.font.color.rgb = SUB
    return tb


def dtable(s, data, x=0.65, y=1.85, w=12.05, h=4.0, size=12.5, col_widths=None, header_color=CARD2):
    rows, cols = len(data), len(data[0])
    tbl = s.shapes.add_table(rows, cols, Inches(x), Inches(y), Inches(w), Inches(h)).table
    if col_widths:
        for i, cw in enumerate(col_widths):
            tbl.columns[i].width = Inches(cw)
    for i, row in enumerate(data):
        for j, val in enumerate(row):
            c = tbl.cell(i, j)
            c.fill.solid()
            c.fill.fore_color.rgb = header_color if i == 0 else (CARD if i % 2 else CARD2)
            c.margin_left = Inches(0.10); c.margin_right = Inches(0.08)
            c.margin_top = Inches(0.05); c.margin_bottom = Inches(0.05)
            tf = c.text_frame
            tf.word_wrap = True
            tf.clear()
            p = tf.paragraphs[0]
            r = p.add_run()          # explicit run => font always applied in every renderer
            r.text = str(val)
            r.font.size = Pt(size)
            r.font.bold = (i == 0 or j == 0)
            r.font.color.rgb = SKY if i == 0 else TXT
    return tbl


def notes(s, t):
    s.notes_slide.notes_text_frame.text = t


def divider(act, title, subtitle, color=GOLD if False else AMBER):
    s = prs.slides.add_slide(BLANK); add_bg(s)
    txt(s, 1, 2.1, 11, 0.7, [[(act, 18, True, SKY)]])
    txt(s, 1, 2.7, 11.3, 1.4, [[(title, 48, True, TXT)]])
    txt(s, 1, 4.15, 11.3, 0.7, [[(subtitle, 19, False, AMBER)]])
    ln = s.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(1), Inches(5.1), Inches(2.4), Pt(4))
    ln.fill.solid(); ln.fill.fore_color.rgb = SKY; ln.line.fill.background()
    notes(s, "SECTION: " + subtitle)
    return s


N = [0]
def new_slide(section, title, color=SKY):
    N[0] += 1
    s = prs.slides.add_slide(BLANK); add_bg(s)
    header(s, section, title, color); footer(s, N[0])
    return s


# ============ 1 TITLE ============
s = prs.slides.add_slide(BLANK); add_bg(s)
glow = s.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(0.9), Inches(1.1), Inches(0.14), Inches(5.3))
glow.adjustments[0] = 0.5; glow.fill.solid(); glow.fill.fore_color.rgb = SKY; glow.line.fill.background()
pill(s, 1.35, 1.25, "CAPSTONE PROTOTYPE + RESEARCH ROADMAP", SKY, w=4.6)
txt(s, 1.3, 1.85, 11.4, 2.6, [
    [("AI-Driven", 58, True, TXT)],
    [("Drug Discovery", 58, True, SKY)],
])
txt(s, 1.3, 4.7, 11.4, 0.9, [
    [("From predicting protein binders to designing tomorrow's molecules — "
      "a working system, real results, and the generative future.", 18, False, SUB)],
])
for i, (big, lab) in enumerate([("8,604", "curated EGFR training labels"),
                                ("ρ 0.71", "ranking accuracy, unseen chemistry"),
                                ("20+", "protein targets in one engine"),
                                ("~30 s", "to screen 100,000 molecules")]):
    stat_card(s, 1.3 + i * 3.0, 5.7, 2.75, 1.15, big, lab, [SKY, GREEN, VIOLET, AMBER][i])
notes(s, "HOOK: a new drug costs ~$1–2B and ~10 years, mostly spent on molecules that fail. This system learns from public experiments which molecules deserve the lab — and it's already running. Three acts: the field, the prototype, the generative future.")

# ============ 2 AGENDA ============
s = new_slide("AGENDA", "Three acts")
for i, (a, t, d) in enumerate([
        ("Ⅰ", "The Problem & the Field", "Why discovery is slow · core vocabulary · the three computational toolkits"),
        ("Ⅱ", "Our Prototype", "Trained pipeline · honest accuracy · live 3-tab app · 20+ protein models"),
        ("Ⅲ", "Future Vision", "Property-directed generation · molecule surgery · 3D-aware design · self-made data")]):
    card(s, 0.85, 2.0 + i * 1.62, 11.6, 1.38, fill=CARD, line=[SKY, GREEN, AMBER][i])
    txt(s, 1.15, 2.14 + i * 1.62, 1.1, 1.1, [[(a, 34, True, [SKY, GREEN, AMBER][i])]])
    txt(s, 2.35, 2.22 + i * 1.62, 10.0, 1.1, [
        [(t, 19, True, TXT)], [(d, 13, False, SUB)]], sp_after=2)
notes(s, "4 min of vocabulary, then the working system, then the vision. Welcome accuracy challenges at the end.")

# ============ DIVIDER I ============
divider("ACT Ⅰ", "The problem & the field", "Shared vocabulary in four minutes")

# ============ 4 PROBLEM ============
s = new_slide("ACT Ⅰ · PROBLEM", "Why drug discovery is slow")
stat_card(s, 0.7, 1.95, 3.85, 1.5, "$1–2 B", "typical R&D cost per approved drug", RED, "💸")
stat_card(s, 4.75, 1.95, 3.85, 1.5, "~10 yrs", "from first idea to pharmacy shelf", AMBER, "⏳")
stat_card(s, 8.8, 1.95, 3.85, 1.5, "10⁶⁰", "possible drug-like molecules to search", SKY, "🌌")
ibullets(s, [
    ("🧪", "The lab is the bottleneck", "each binding experiment costs days + money; a campaign tests ~10⁴ molecules out of 10⁶⁰"),
    ("🎯", "So the real question is not 'test more'", "it's 'test smarter' — predict binding before buying the experiment"),
    ("💡", "Even a rough prediction changes the economics", "50 informed candidates beat 50,000 random ones"),
], y=3.95, size=15.5)
notes(s, "Frame AI as an experiment-spending optimizer, not a lab replacement.")

# ============ 5 CONCEPTS ============
s = new_slide("ACT Ⅰ · VOCABULARY", "Four words that unlock everything")
dtable(s, [
    ["Term", "Plane meaning", "Example"],
    ["Protein target", "The machine a drug must switch off", "EGFR → lung cancer · BRAF → melanoma"],
    ["Molecule / ligand", "The 'key' for the protein's 'lock'", "'afatinib', or any candidate compound"],
    ["SMILES", "Any molecule as one line of text", "aspirin = CC(=O)Oc1ccccc1C(=O)O"],
    ["Binding affinity / IC50", "How tightly the key fits", "10 nM = excellent · 10,000 nM = ignore"],
], size=13, col_widths=[3.1, 4.7, 4.2], h=4.3)
notes(s, "60-second anchor. SMILES is what lets us feed chemistry to a computer.")

# ============ 6 TOOLKITS ============
s = new_slide("ACT Ⅰ · LANDSCAPE", "Three computational toolkits")
dtable(s, [
    ["Toolkit", "Core idea", "Needs", "Superpower", "Weakness"],
    ["Physics — docking / FEP", "Simulate the key twisting into the 3D lock", "3D structure only", "Works on day 1; shows HOW it binds", "Slow; scores noisy (±2–3 log)"],
    ["ML / QSAR — ours", "Learn potency patterns from past experiments", "1,000s of labels", "Millisecond scoring; most accurate on known targets", "Cold start on brand-new targets"],
    ["Generative AI", "Learn chemistry's grammar, write NEW molecules", "Big corpora + objectives", "Invents novel property-tuned candidates", "Must be validated for reality"],
], size=12, col_widths=[3.2, 3.5, 1.9, 3.3, 2.9], h=4.5)
notes(s, "They are complementary, not rivals. Act III is about chaining them: generate → predict → dock → verify.")

# ============ DIVIDER II ============
divider("ACT Ⅱ", "Our prototype", "DrugDiscovery Studio — real data, honest numbers, live app")

# ============ 8 PIPELINE ============
s = new_slide("PROTOTYPE · PIPELINE", "From public data to live predictions")
steps = [("1", "Ingest", "ChEMBL + UniProt APIs, any human protein", SKY),
         ("2", "Curate", "salts out · dupes merged · mutants out · conflicts out", GREEN),
         ("3", "Featurize", "SMILES → 2,048-bit ECFP fingerprints, disk-cached", VIOLET),
         ("4", "Train", "LightGBM ×7 ensemble (+ GNN research track)", AMBER),
         ("5", "Honest exam", "scaffold split — test set = 100% unseen chemistry", RED),
         ("6", "Serve", "web app: train any protein · screen · design", SKY)]
for i, (n, t, d, c) in enumerate(steps):
    x = 0.7 + (i % 3) * 4.15; y = 1.95 + (i // 3) * 2.35
    card(s, x, y, 3.9, 2.1, fill=CARD, line=c)
    txt(s, x + 0.25, y + 0.15, 1, 0.7, [[(n, 26, True, c)]])
    txt(s, x + 0.25, y + 0.72, 3.4, 1.3, [[(t, 15.5, True, TXT)], [(d, 11.5, False, SUB)]], sp_after=2)
notes(s, "One command (run_pipeline.py) reproduces steps 1–5 end-to-end.")

# ============ 9 FUNNEL ============
s = new_slide("PROTOTYPE · DATA QUALITY", "Curated like it's our lab notebook")
card(s, 0.7, 1.85, 7.3, 5.0, fill=CARD)
s.shapes.add_picture("artifacts/dark_funnel.png", Inches(0.95), Inches(2.25), width=Inches(6.85))
ibullets(s, [
    ("🧹", "6,236 mutant-assay rows removed", "structured flags + curated keywords"),
    ("📄", "2,316 duplicate publications dropped", ""),
    ("⚖️", "652 contradictory compounds dropped", ">1-log disagreement"),
], x=8.25, y=2.2, w=4.5, size=13.5, gap=12)
notes(s, "The mutant removal is what later lets the model correctly call osimertinib weak on normal EGFR.")

# ============ 10 TWO TIERS ============
s = new_slide("PROTOTYPE · MODELS", "Two tiers — chosen by data, not fashion")
card(s, 0.7, 1.95, 5.9, 4.6, fill=CARD, line=SKY)
txt(s, 0.95, 2.1, 5.4, 0.6, [[("TIER A — production 🚀", 18, True, SKY)]])
ibullets(s, [
    ("", "ECFP fingerprint → 7 LightGBM models", ""),
    ("", "mean = prediction · disagreement = uncertainty", ""),
    ("", "trains in ~40 s · scores 3k molecules/s", ""),
], x=0.95, y=2.75, w=5.4, size=12.5, gap=7)
card(s, 6.85, 1.95, 5.9, 4.6, fill=CARD, line=AMBER)
txt(s, 7.1, 2.1, 5.4, 0.6, [[("TIER B — research 🔬", 18, True, AMBER)]])
ibullets(s, [
    ("", "graph neural net: atoms=nodes, bonds=edges", ""),
    ("", "+ protein-sequence embedding · MC-dropout", ""),
    ("", "loses today (R² 0.39) — wins at 10× data;", ""),
    ("", "its protein embedding = path to ONE universal model", ""),
], x=7.1, y=2.75, w=5.4, size=12.5, gap=7, color=AMBER)
notes(s, "'Why not deep learning?' → we built both and measured. Gradient boosting wins at this scale; Tier B is our transfer-learning future.")

# ============ 11 HONEST EXAM ============
s = new_slide("PROTOTYPE · EVALUATION", "The exam contains only NEW chemistry")
stat_card(s, 0.7, 1.95, 3.7, 1.45, "859", "test molecules", SKY)
stat_card(s, 4.6, 1.95, 3.7, 1.45, "859", "unique unseen scaffolds", VIOLET)
stat_card(s, 8.5, 1.95, 4.1, 1.45, "0", "structural leaks into testing", GREEN)
ibullets(s, [
    ("⚠️", "Random splits lie", "lookalike molecules inflate accuracy"),
    ("🧬", "We split by molecular skeleton (Bemis–Murcko)", "a core shape lives in train XOR test, never both"),
    ("✅", "So our numbers are the honest lower bound", "what you'd see in the field on novel compounds"),
], y=3.85, size=15, gap=11)
notes(s, "This is the methodological rigor slide reviewers ask about first.")

# ============ 12 RESULTS ============
s = new_slide("PROTOTYPE · RESULTS", "Accuracy on never-before-seen chemistry")
card(s, 0.7, 1.8, 6.4, 5.1, fill=CARD)
s.shapes.add_picture("artifacts/dark_scatter.png", Inches(0.95), Inches(1.95), height=Inches(4.9))
card(s, 7.35, 1.8, 5.35, 5.1, fill=CARD)
s.shapes.add_picture("artifacts/dark_metrics.png", Inches(7.6), Inches(2.15), width=Inches(4.9))
txt(s, 7.6, 5.75, 4.9, 1.0, [
    [("Red points (uncertain) scatter more — the confidence signal is working.", 12.5, False, SUB)]])
notes(s, "Left: prediction vs truth on the scaffold-held-out test set. Right: Tier A outperforms the GNN across all four metrics at this data scale.")

# ============ 13 UNCERTAINTY ============
s = new_slide("PROTOTYPE · CONFIDENCE", "Every number comes with a trust rating")
card(s, 0.7, 1.85, 6.3, 5.0, fill=CARD)
s.shapes.add_picture("artifacts/dark_uncertainty.png", Inches(1.0), Inches(2.1), width=Inches(5.7))
ibullets(s, [
    ("🟢", "Most confident quartile: MAE ≈ 0.51", "usable as-is for ranking"),
    ("🔴", "Least confident: MAE ≈ 0.77", "flag to verify early"),
    ("🧭", "Same potency ≠ same trust", "green/amber/red pills in every result"),
], x=7.35, y=2.3, w=5.3, size=15, gap=14)
notes(s, "The ensemble's disagreement, calibrated on validation data. Knowing when NOT to trust a model saves more money than raw accuracy.")

# ============ 14 REALITY CHECK ============
s = new_slide("PROTOTYPE · REALITY CHECK", "The AI reproduces clinical pharmacology")
dtable(s, [
    ["Drug", "Model says (normal EGFR)", "Clinical reality"],
    ["Afatinib", "~4 nM · excellent 🟢", "Most potent in class ✓"],
    ["Dacomitinib", "~8 nM", "2nd-gen covalent EGFRi ✓"],
    ["Erlotinib / Gefitinib", "~9–27 nM", "1st-gen standards ✓"],
    ["Osimertinib", "~280 nM · 'weak' ⚠️", "CORRECT — designed to hit MUTANT EGFR only ✓"],
    ["Vemurafenib (→ BRAF model)", "~74 nM", "Real value ≈ 30 nM ✓"],
], size=12.5, col_widths=[3.5, 4.3, 4.25], h=4.4)
notes(s, "Osimertinib: trained on wild-type EGFR only, the model still 'knows' the mutant-selective drug is weak here. Drug selectivity logic learned straight from curated data.")

# ============ 15 APP ============
s = new_slide("PROTOTYPE · THE APP", "Three tabs a scientist actually uses")
for i, (t, ic, d1, d2) in enumerate([
        ("Target Hub", "🎯", "Type ANY protein (BRAF, JAK2, DRD2…)",
         "UniProt→ChEMBL lookup · data report · ~4-min auto-train · per-model exam score"),
        ("Screen", "🧪", "Paste/upload up to 10,000 molecules",
         "ranked IC50 + confidence pills + drug-likeness + CSV export · top-known binders one click"),
        ("Design", "🧬", "Pick protein & count → evolve NEW molecules",
         "genetic algorithm: potency × drug-likeness × confidence · novelty flags per candidate")]):
    y = 1.95 + i * 1.66
    card(s, 0.7, y, 12.0, 1.45, fill=CARD, line=[SKY, GREEN, AMBER][i])
    txt(s, 1.0, y + 0.14, 1.1, 1.2, [[(ic, 30, True, [SKY, GREEN, AMBER][i])]])
    txt(s, 2.2, y + 0.16, 10.2, 1.2, [
        [(f"{i+1} · {t} — ", 15.5, True, TXT), (d1, 15.5, False, SUB)],
        [(d2, 12, False, SUB)]], sp_after=2)
notes(s, "DEMO (90 s): Screen → load 5-drug example → Score (1 s). Design → 12 candidates (~60 s): 'these molecules do not exist; the AI proposed them.' Hub → type audience's protein.")

# ============ 16 MULTI PROTEIN ============
s = new_slide("PROTOTYPE · SCALE", "One engine → many diseases")
stat_card(s, 0.7, 1.95, 3.8, 1.5, "20+", "targets in the training queue", SKY, "🧩")
stat_card(s, 4.75, 1.95, 3.8, 1.5, "0.65–0.75", "Spearman range across trained models", GREEN, "📈")
stat_card(s, 8.8, 1.95, 3.85, 1.5, "~4 min", "to add any NEW protein", AMBER, "⚡")
ibullets(s, [
    ("🧬", "Protein-centric, not disease-centric", "the day a new disease maps to a trained protein → screening starts the same afternoon"),
    ("⛔", "Honest gate", "protein with <300 public compounds → app says 'not enough data' instead of faking a model"),
    ("📋", "Every model keeps its report card", "RMSE / R² / ρ shown on its card before you trust it"),
], y=3.9, size=15, gap=12)
notes(s, "Queue: CDK2, CDK9, JAK2, ALK, MET, PARP1, HDAC1, DRD2, ADRB2, HTR2A, HSP90, PIK3CA, mTOR, AKT1, HER2, ABL1, VEGFR2, SRC, ACE, AR.")

# ============ 17 SPEED ============
s = new_slide("PROTOTYPE · THROUGHPUT", "Built for libraries, not demos")
dtable(s, [
    ["Operation", "Speed", "Practical meaning"],
    ["Fingerprint 1,000 molecules", "~0.2 s", "featurization is effectively free"],
    ["Score 1,000 with uncertainty", "~0.34 s", "100k compounds in ~30 s"],
    ["Score 1,000 point estimate", "~0.03 s", "1M library pre-screened in ~30 s"],
    ["Design 15 novel candidates", "~60–90 s", "a chemist's week of sketching, on demand"],
], size=13, col_widths=[4.3, 2.4, 5.3], h=3.9)
txt(s, 0.7, 6.05, 12, 0.5, [[("Pro workflow: point-predict millions → re-score top slice with full uncertainty → dock the top 100.", 13, False, SUB)]])
notes(s, "Throughput measured on the real sandbox CPU, not quoted from papers.")

# ============ DIVIDER III ============
divider("ACT Ⅲ", "The future vision", "From predicting molecules to creating them")

# ============ 19 VISION 1 ============
s = new_slide("VISION · 01", "Generation by property wishlist", AMBER)
card(s, 0.7, 1.95, 12.0, 0.95, fill=CARD2, line=AMBER)
txt(s, 0.95, 2.08, 11.6, 0.7, [[("“Potent vs BRAF · spare EGFR · oral · soluble · patentable”", 17, True, TXT)]])
ibullets(s, [
    ("📟", "Today", "GA optimizes potency × QED × confidence around known scaffolds"),
    ("🧠", "Next", "RL / graph-diffusion generators scoring an explicit property scorecard — potency + selectivity + solubility + stability + synthesizability, all at once"),
    ("🎯", "Selectivity becomes a constraint", "score each candidate against our 20+ models: 'hit BRAF, AVOID EGFR' is now just arithmetic"),
    ("📈", "Output", "a Pareto front, not one molecule — chemists choose their trade-offs consciously"),
], y=3.2, size=14.5, gap=10, color=AMBER)
notes(s, "Generation matures from 'strong binders' to 'full clinical product profile'. Selectivity scoring across models is already possible in code.")

# ============ 20 VISION 2 ============
s = new_slide("VISION · 02", "Molecule modification on demand", AMBER)
ibullets(s, [
    ("🧰", "The real daily need", "not 'invent from zero' — 'fix THIS one': same core, new handle"),
    ("✂️", "Edit menu", "grow/shrink/ swap R-groups · cyclize floppy chains · ring-atom swaps · block metabolic hotspots"),
    ("📚", "How it learns edits", "matched-molecular-pair rules mined from millions of historical analog programs"),
    ("✅", "Validated proposals", "each analog returned with predicted Δpotency, Δsolubility, Δdrug-likeness and a confidence tag"),
], y=1.95, size=16, gap=14, color=AMBER)
stat_card(s, 0.7, 5.4, 12.0, 1.15, "80%+", "of real medicinal chemistry is series optimization — this mode serves it directly", SKY, "🧑‍🔬")
notes(s, "Lead optimization is where pharma spends its life. A fixed-core constraint on our GA already gives a working alpha.")

# ============ 21 VISION 3 ============
s = new_slide("VISION · 03", "3D-structure-aware everything", AMBER)
ibullets(s, [
    ("📦", "Structures are free at scale", "PDB crystals (EGFR 1M17) + AlphaFold ≈ every human protein"),
    ("🔌", "Near-term here", "dock the app's top-100 into the pocket (AutoDock Vina) → poses + consensus re-scoring + 3D pose viewer"),
    ("🧊", "Deeper models", "E(n)-equivariant GNNs & diffusion binders learn from pocket geometry directly, not memorized fingerprints"),
    ("🔍", "The payoff", "catch 2D false-positives, and EXPLAIN binding atom-by-atom — the trust layer scientists need"),
], y=1.95, size=16, gap=14, color=AMBER)
notes(s, "1M17: the EGFR crystal with erlotinib visibly sitting in the ATP pocket — the perfect teaching image for this idea.")

# ============ 22 VISION 4 ============
s = new_slide("VISION · 04", "Self-generated training data", AMBER)
dtable(s, [
    ["Data tier", "Source", "Accuracy", "Cost", "Role"],
    ["Pseudo-labels", "Docking 1–5k molecules into the pocket", "±2–3 log", "s / mol · CPU", "bootstrap a ranking model on day 1"],
    ["Physical labels", "Free-energy (FEP) on top hundreds", "~1 log", "hrs / mol · GPU", "calibrate & correct the bootstrap"],
    ["Real labels", "A few dozen smart wet-lab assays", "ground truth", "high", "anchor; choose maximally-informative ones"],
], size=13, col_widths=[2.4, 4.1, 2.0, 2.1, 3.4], h=3.6)
txt(s, 0.7, 5.8, 12.0, 0.9, [
    [("🔁 The loop is the product:  Bootstrap → screen billions → FEP the top → buy a few perfect experiments → retrain. "
      "Every cycle, the model converts from guessing physics to knowing the protein — this is active learning, the industry playbook for a brand-new target.", 13, False, SUB)]])
notes(s, "This answers 'could AI help on a brand-new protein?': yes, with this ladder and honest confidence flags — never pretending pseudo-labels are truth.")

# ============ 23 ROADMAP ============
s = new_slide("ROADMAP", "Ordered by build cost — not glamour")
dtable(s, [
    ["Horizon", "Deliverable", "Why first / impact"],
    ["Days", "Fixed-core GA + multi-target selectivity scoring", "molecule-modification mode & selectivity decisions — in current code"],
    ["Weeks", "Vina docking + 3D pose viewer + docking-label bootstrap", "covers data-poor proteins honestly; catches 2D false-positives"],
    ["Months", "SELFIES/diffusion generator trained on 3M ChEMBL compounds", "true de-novo creation conditioned on our models"],
    ["Next", "Active-learning loop with FEP + wet-lab feedback", "each real experiment permanently shrinks error"],
    ["Endgame", "Conversational co-pilot: protein + wishlist → validated candidates", "the complete generative pipeline"],
], size=12.5, col_widths=[2.0, 5.4, 4.6], h=4.4)
notes(s, "Each stage is a deliverable on its own — no big-bang risk.")

# ============ 24 LIMITS ============
s = new_slide("INTEGRITY", "What this does NOT do — and why that's fine", RED)
ibullets(s, [
    ("🧬", "It ranks binders", "biology decides whether binding = medicine"),
    ("⚠️", "±1 log-unit error is real", "shortlists, not verdicts; novel designs need synthesis + assay"),
    ("☠️", "Toxicity & ADME are only proxy-scored", "real safety panels remain essential"),
    ("🛡️", "Dual-use awareness", "generative chemistry needs governance as it grows — we build for therapeutics"),
], y=1.95, size=16, gap=16, color=RED)
notes(s, "Own the limits before the audience finds them — skeptics become collaborators.")

# ============ 25 THANK YOU ============
s = prs.slides.add_slide(BLANK); add_bg(s)
glow = s.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(0.9), Inches(1.5), Inches(0.14), Inches(4.5))
glow.adjustments[0] = 0.5; glow.fill.solid(); glow.fill.fore_color.rgb = SKY; glow.line.fill.background()
txt(s, 1.35, 2.3, 11.3, 1.2, [[("Thank you — questions?", 48, True, TXT)]])
txt(s, 1.35, 3.6, 11.2, 2.4, [
    [("🧪  Live demo: 5-drug screen in 1 s · design 15 novel candidates in 60 s", 16, False, SUB)],
    [("🎯  Trained on public data (ChEMBL / UniProt) · Docker-deployable", 16, False, SUB)],
    [("🧬  Act I → Act III: predict what binds → create what's needed", 16, False, SKY)],
], sp_after=12)
notes(s, "Q&A hints: AlphaFold? complementary. Accuracy? ρ 0.71–0.75 ranking on unseen chemistry. COVID day-1? no data = no miracle; docking+transfer from week ~6; fully armed by late-2020. Private data? drop-in CSV, <1 min retrain. Synthesizability? QED + chemist review mandatory.")

prs.save("DrugDiscovery_Studio_v3.pptx")
print("slides:", len(prs.slides._sldIdLst))
