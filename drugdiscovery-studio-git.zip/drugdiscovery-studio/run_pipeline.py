"""
End-to-end orchestrator for the EGFR binding-affinity pipeline.

    python run_pipeline.py [--skip-download] [--with-kinase-family] [--esm]

Steps: download -> assay confidence -> clean -> scaffold split -> featurize
-> Tier A (LightGBM ensemble) -> Tier B (GNN + target embedding).
Individual steps are also runnable directly (see each src/*.py for CLI args).
"""
import argparse
import subprocess
import sys

PY = sys.executable


def sh(cmd):
    print(f"\n>>> {' '.join(cmd)}", flush=True)
    r = subprocess.run(cmd)
    if r.returncode != 0:
        raise SystemExit(f"failed: {' '.join(cmd)}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--skip-download", action="store_true")
    ap.add_argument("--with-kinase-family", action="store_true",
                    help="fetch related-kinase data and pretrain Tier B (transfer learning)")
    ap.add_argument("--esm", action="store_true", help="use ESM2 embedding for Tier B")
    args = ap.parse_args()

    if not args.skip_download:
        dl = [PY, "src/download_chembl.py", "--target", "CHEMBL203",
              "--out", "data/raw/egfr_chembl203.csv"]
        if args.with_kinase_family:
            dl.append("--fetch-kinase-family")
        sh(dl)
        sh([PY, "src/fetch_assay_confidence.py",
            "--activities", "data/raw/egfr_chembl203.csv"])

    sh([PY, "src/data_prep.py", "--in", "data/raw/egfr_chembl203.csv",
        "--out", "data/processed/egfr_clean.csv"])
    sh([PY, "src/scaffold_split.py", "--in", "data/processed/egfr_clean.csv",
        "--out", "data/processed/egfr_split.csv"])
    sh([PY, "src/features.py", "--in", "data/processed/egfr_split.csv",
        "--cache", "data/processed/fp2048.npz"])
    sh([PY, "src/tier_a.py", "--split", "data/processed/egfr_split.csv",
        "--cache", "data/processed/fp2048.npz", "--out", "artifacts/tier_a"])

    tb = [PY, "src/tier_b.py", "--split", "data/processed/egfr_split.csv",
          "--fasta", "data/raw/egfr_P00533.fasta",
          "--graph-cache", "data/processed/graphs.pkl", "--out", "artifacts/tier_b"]
    if args.esm:
        tb.append("--esm")
    if args.with_kinase_family:
        sh([PY, "src/data_prep.py", "--in", "data/raw/egfr_chembl203_kinase_family.csv",
            "--out", "data/processed/kinase_family_clean.csv", "--keep-mutant-assays"])
        tb += ["--pretrain", "data/processed/kinase_family_clean.csv"]
    sh(tb)

    print("\nDone. Metrics: artifacts/tier_a/metrics.json, artifacts/tier_b/metrics.json")


if __name__ == "__main__":
    main()
